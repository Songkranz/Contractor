<?php
require __DIR__ . '/includes/payments.php'; $user = require_user();
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$payment = payment_for_user($id, $user); $errors = []; $decision = 'approve'; $reviewNote = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_reviewer($user)) { http_response_code(403); exit('คุณไม่มีสิทธิ์ตรวจหลักฐานการชำระเงิน'); }
    verify_csrf(); $decision = post_string('decision'); $reviewNote = post_string('review_note');
    if (!in_array($decision, ['approve', 'reject'], true)) { $errors[] = 'กรุณาเลือกผลตรวจหลักฐาน'; }
    if (mb_strlen($reviewNote) > 2000) { $errors[] = 'หมายเหตุต้องไม่เกิน 2,000 ตัวอักษร'; }
    if ($decision === 'reject' && mb_strlen($reviewNote) < 5) { $errors[] = 'กรุณาระบุเหตุผลที่หลักฐานไม่ผ่านอย่างน้อย 5 ตัวอักษร'; }
    if ($decision === 'approve' && post_string('checked_evidence') !== '1') { $errors[] = 'กรุณายืนยันว่าได้ตรวจสอบยอด วันเวลา และผู้รับเงินแล้ว'; }
    if ($payment['status'] !== 'pending') { $errors[] = 'หลักฐานนี้ได้รับการตรวจแล้ว ไม่สามารถบันทึกผลซ้ำได้'; }
    if (!$errors) {
        try {
            db()->beginTransaction();
            $stmt = db()->prepare('SELECT status, deposit_amount FROM service_requests WHERE id = ? FOR UPDATE'); $stmt->execute([$payment['request_id']]); $request = $stmt->fetch();
            $stmt = db()->prepare('SELECT status, amount FROM deposit_payments WHERE id = ? FOR UPDATE'); $stmt->execute([$id]); $locked = $stmt->fetch();
            if (!$locked || $locked['status'] !== 'pending' || !$request || $request['status'] !== 'payment_review') { throw new DomainException('สถานะเปลี่ยนแปลงหรือมีทีมงานตรวจหลักฐานนี้แล้ว กรุณาตรวจสอบผลล่าสุด'); }
            if ($decision === 'approve' && money_cents($locked['amount']) !== money_cents($request['deposit_amount'])) { throw new DomainException('ยอดมัดจำของหลักฐานไม่ตรงกับคำขอ กรุณาปฏิเสธหลักฐานพร้อมแจ้งเหตุผล'); }
            $approved = $decision === 'approve';
            $paymentStatus = $approved ? 'approved' : 'rejected'; $requestStatus = $approved ? 'ready' : 'awaiting_deposit';
            $stmt = db()->prepare('UPDATE deposit_payments SET status = ?, review_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?');
            $stmt->execute([$paymentStatus, $reviewNote ?: null, $user['id'], $id]);
            $stmt = db()->prepare('UPDATE service_requests SET status = ? WHERE id = ?'); $stmt->execute([$requestStatus, $payment['request_id']]);
            $note = $approved ? 'ทีมงานอนุมัติหลักฐาน ' . payment_number($id) . ' ค่ามัดจำ ' . money($locked['amount']) : 'หลักฐาน ' . payment_number($id) . ' ไม่ผ่าน: ' . $reviewNote;
            $stmt = db()->prepare('INSERT INTO request_status_history (request_id, actor_id, status, note) VALUES (?, ?, ?, ?)'); $stmt->execute([$payment['request_id'], $user['id'], $requestStatus, $note]);
            db()->commit(); flash($approved ? 'อนุมัติสลิปแล้ว งานเปลี่ยนเป็นเตรียมดำเนินงาน' : 'แจ้งหลักฐานไม่ผ่านแล้ว ลูกค้าสามารถดูเหตุผลและส่งใหม่ได้'); redirect('payment.php?id=' . $id);
        } catch (Throwable $exception) {
            if (db()->inTransaction()) { db()->rollBack(); }
            if ($exception instanceof DomainException) { $errors[] = $exception->getMessage(); }
            else { error_log($exception->getMessage()); $errors[] = 'บันทึกผลไม่สำเร็จ กรุณาลองใหม่'; }
            $payment = payment_for_user($id, $user);
        }
    }
}
$title = payment_number($id); require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="request.php?id=<?= (int) $payment['request_id'] ?>">← กลับคำขอ <?= request_number((int) $payment['request_id']) ?></a><div class="workspace-heading"><div><p class="eyebrow"><?= payment_number($id) ?> · DEPOSIT EVIDENCE</p><h1>หลักฐานค่ามัดจำ</h1><p class="subtle"><?= e($payment['request_title']) ?></p></div><span class="payment-badge payment-<?= e($payment['status']) ?>"><?= e(payment_label($payment['status'])) ?></span></div>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="request-layout payment-layout"><section class="panel"><p class="eyebrow">TRANSFER SLIP</p><h2>ภาพหลักฐานการโอน</h2><a class="slip-preview" href="payment-image.php?id=<?= $id ?>" target="_blank" rel="noopener"><img src="payment-image.php?id=<?= $id ?>" alt="ภาพสลิปค่ามัดจำ <?= payment_number($id) ?>"><span>เปิดภาพขนาดเต็ม ↗</span></a><p class="subtle">หลักฐานที่ลูกค้าส่งเมื่อ <?= e(short_date($payment['created_at'])) ?></p></section>
<aside class="request-aside"><section class="panel"><p class="eyebrow">PAYMENT DETAILS</p><h2><?= money($payment['amount']) ?></h2><dl><div><dt>ยอดมัดจำ</dt><dd><?= money($payment['deposit_amount']) ?></dd></div><div><dt>วันเวลาโอน</dt><dd><?= $payment['transferred_at'] ? e(short_date($payment['transferred_at'])) : 'ตรวจสอบจากภาพสลิป' ?></dd></div><div><dt>ส่งโดย</dt><dd><?= e($payment['customer_name']) ?></dd></div><div><dt>เลขคำขอ</dt><dd><a href="request.php?id=<?= (int) $payment['request_id'] ?>"><?= request_number((int) $payment['request_id']) ?></a></dd></div></dl><?php if ($payment['customer_note']): ?><h3>หมายเหตุจากลูกค้า</h3><p class="preserve-lines"><?= e($payment['customer_note']) ?></p><?php endif; ?></section>
<?php if ($payment['status'] !== 'pending'): ?><section class="panel <?= $payment['status'] === 'approved' ? 'accent-panel' : '' ?>"><p class="eyebrow">REVIEW RESULT</p><h2><?= e(payment_label($payment['status'])) ?></h2><?php if ($payment['review_note']): ?><h3><?= $payment['status'] === 'rejected' ? 'เหตุผลที่ไม่ผ่าน' : 'หมายเหตุจากทีมงาน' ?></h3><p class="preserve-lines"><?= e($payment['review_note']) ?></p><?php endif; ?><p class="subtle">ตรวจโดย <?= e($payment['reviewer_name']) ?><br><?= e(short_date($payment['reviewed_at'])) ?></p><?php if ($user['role'] === 'customer' && $payment['status'] === 'rejected' && $payment['request_status'] === 'awaiting_deposit'): ?><a class="button full-width" href="payment-new.php?request_id=<?= (int) $payment['request_id'] ?>">ส่งหลักฐานใหม่ ↗</a><?php endif; ?></section>
<?php elseif (is_reviewer($user)): ?><section class="form-card"><p class="eyebrow">STAFF REVIEW</p><h2>ตรวจหลักฐาน</h2><form method="post" class="stack-form" data-payment-review><?= csrf() ?>
<label>ผลตรวจสลิป<select name="decision" data-payment-decision><option value="approve" <?= $decision === 'approve' ? 'selected' : '' ?>>อนุมัติสลิป</option><option value="reject" <?= $decision === 'reject' ? 'selected' : '' ?>>หลักฐานไม่ผ่าน</option></select></label>
<label class="checkbox-label payment-confirm" data-payment-confirm><input type="checkbox" name="checked_evidence" value="1" <?= post_string('checked_evidence') === '1' ? 'checked' : '' ?>> ตรวจสอบยอด วันเวลา และผู้รับเงินแล้ว</label>
<label><span data-payment-note-label>หมายเหตุ / เหตุผลที่ไม่ผ่าน</span><textarea name="review_note" rows="4" maxlength="2000" data-payment-note placeholder="แจ้งข้อมูลให้ลูกค้าทราบ"><?= e($reviewNote) ?></textarea></label><button class="button full-width" type="submit">บันทึกผลตรวจสลิป ↗</button></form></section>
<?php else: ?><section class="panel accent-panel"><h2>รอทีมงานตรวจสอบ</h2><p>คุณส่งหลักฐานแล้ว ทีมงานจะตรวจและแจ้งผลในหน้านี้</p><a class="text-link" href="request.php?id=<?= (int) $payment['request_id'] ?>">ดูสถานะคำขอ →</a></section><?php endif; ?></aside></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
