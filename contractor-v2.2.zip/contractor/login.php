<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) { redirect('dashboard.php'); }
$error = ''; $identifier = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $identifier = post_string('identifier');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$identifier, $identifier]); $account = $stmt->fetch();
    // A valid fallback hash keeps password verification on the unknown-account path too.
    $hash = $account['password_hash'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
    if (password_verify($password, $hash) && $account) {
        session_regenerate_id(true);
        $_SESSION = ['user_id' => (int) $account['id'], 'csrf' => bin2hex(random_bytes(32))];
        redirect('dashboard.php');
    }
    $error = 'ชื่อผู้ใช้ อีเมล หรือรหัสผ่านไม่ถูกต้อง';
}
$title = 'เข้าสู่ระบบ'; require __DIR__ . '/includes/header.php';
?>
<main class="auth-layout container"><aside class="auth-intro"><p class="eyebrow">WELCOME BACK</p><h1>ยินดีต้อนรับ<br>กลับ<span>สู่พื้นที่ของคุณ</span></h1><p>เข้าสู่ระบบเพื่อจัดการข้อมูล<br>และเข้าถึงพื้นที่ทำงานตามสิทธิ์ของคุณ</p><div class="auth-decoration" aria-hidden="true">S<span>.</span></div></aside>
<section class="form-card login-card"><p class="eyebrow">YOUR WORKSPACE</p><h2>เข้าสู่ระบบ</h2><p class="subtle">ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a></p>
<?php if ($error): ?><div class="alert error" role="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="stack-form"><?= csrf() ?>
<label>ชื่อผู้ใช้หรืออีเมล<input name="identifier" autocomplete="username" required maxlength="190" value="<?= e($identifier) ?>" placeholder="ชื่อผู้ใช้หรือ you@example.com"></label>
<label>รหัสผ่าน<input type="password" name="password" autocomplete="current-password" required maxlength="72" placeholder="กรอกรหัสผ่านของคุณ"></label>
<label class="checkbox-label"><input type="checkbox" data-show-password> แสดงรหัสผ่าน</label>
<button class="button full-width" type="submit">เข้าสู่ระบบ <span aria-hidden="true">↗</span></button>
</form><div class="form-footnote">ลูกค้า พนักงาน และผู้ดูแลระบบ ใช้หน้าเข้าสู่ระบบเดียวกัน</div></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
