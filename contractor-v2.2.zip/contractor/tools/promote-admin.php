<?php
declare(strict_types=1);
// Only run from a terminal: php tools/promote-admin.php your_username
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if (empty($argv[1])) { fwrite(STDERR, "Usage: php tools/promote-admin.php username\n"); exit(1); }
$config = require __DIR__ . '/../config.php';
try {
    $pdo = new PDO('mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4', $config['db_user'], $config['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?'); $stmt->execute([$argv[1]]); $id = $stmt->fetchColumn();
    if (!$id) { fwrite(STDERR, "Account not found. Register first.\n"); exit(1); }
    $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?"); $stmt->execute([$id]);
    echo "Administrator role assigned. Reload dashboard.\n";
} catch (PDOException $e) { fwrite(STDERR, "Database connection or update failed. Check config.php.\n"); exit(1); }
