<?php
require __DIR__ . '/includes/bootstrap.php'; $user = require_user(); $errors = [];
$data = $user;
$addressFields = ['house_number'=>['บ้านเลขที่',50], 'village'=>['หมู่ที่ / หมู่บ้าน',50], 'road'=>['ซอย / ถนน',100], 'subdistrict'=>['ตำบล / แขวง',100], 'district'=>['อำเภอ / เขต',100], 'province'=>['จังหวัด',100], 'postal_code'=>['รหัสไปรษณีย์',5]];
$stmt=db()->prepare('SELECT * FROM user_addresses WHERE user_id=?');$stmt->execute([$user['id']]);$savedAddress=$stmt->fetch();
foreach($addressFields as $key=>$spec){$data[$key]=$savedAddress[$key]??'';}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach (['full_name', 'email', 'phone'] as $field) { $data[$field] = post_string($field); }
    if (mb_strlen($data['full_name']) < 2 || mb_strlen($data['full_name']) > 100) { $errors[] = 'กรุณาระบุชื่อ-นามสกุล 2–100 ตัวอักษร'; }
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) || strlen($data['email']) > 190) { $errors[] = 'กรุณาระบุอีเมลให้ถูกต้อง'; }
    if (!preg_match('/\A[0-9]{9,10}\z/', $data['phone'])) { $errors[] = 'กรุณาระบุเบอร์โทรศัพท์ 9–10 หลัก'; }
    $hasAddress=false;
    foreach($addressFields as $key=>$spec){$data[$key]=post_string($key);if($data[$key]!=='')$hasAddress=true;if(mb_strlen($data[$key])>$spec[1])$errors[]=$spec[0].'ยาวเกินกำหนด';}
    if($hasAddress){
        foreach(['house_number','subdistrict','district','province','postal_code'] as $key){if($data[$key]==='')$errors[]='กรุณาระบุ'.$addressFields[$key][0];}
        if(!preg_match('/\A[0-9]{5}\z/',$data['postal_code']))$errors[]='รหัสไปรษณีย์ต้องเป็นตัวเลข 5 หลัก';
        $parts=[];foreach($addressFields as $key=>$spec){if($data[$key]!=='')$parts[]=$spec[0].' '.$data[$key];}$data['address']=implode(' ', $parts);
    } elseif($savedAddress){$data['address']='';}

    if (!$errors) {
        try {
            db()->beginTransaction();
            $stmt = db()->prepare('UPDATE users SET full_name = ?, email = ?, phone = ?, address = ? WHERE id = ?');
            $stmt->execute([$data['full_name'], $data['email'], $data['phone'], $data['address'], $user['id']]);
            if($hasAddress || $savedAddress){
                $stmt=db()->prepare('INSERT INTO user_addresses (user_id,house_number,village,road,subdistrict,district,province,postal_code) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE house_number=VALUES(house_number),village=VALUES(village),road=VALUES(road),subdistrict=VALUES(subdistrict),district=VALUES(district),province=VALUES(province),postal_code=VALUES(postal_code)');
                $values=[$user['id']];foreach($addressFields as $key=>$spec)$values[]=$data[$key];$stmt->execute($values);
            }
            db()->commit();
            flash('บันทึกข้อมูลส่วนตัวเรียบร้อยแล้ว'); redirect('profile.php');
        } catch (PDOException $exception) {
            if(db()->inTransaction())db()->rollBack();
            if ($exception->getCode() === '23000') { $errors[] = 'อีเมลนี้มีผู้ใช้แล้ว'; }
            else { error_log($exception->getMessage()); $errors[] = 'บันทึกข้อมูลไม่สำเร็จ กรุณาลองใหม่'; }
        }
    }
}
$title = 'ข้อมูลส่วนตัว'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace narrow"><a class="text-link" href="dashboard.php">← กลับแดชบอร์ด</a><div class="workspace-heading"><div><p class="eyebrow">MY PROFILE</p><h1>ข้อมูลส่วนตัว</h1></div><span class="badge"><?= e(role_label($user['role'])) ?></span></div>
<section class="form-card"><?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" class="stack-form"><?= csrf() ?>
<label>ชื่อผู้ใช้<input value="<?= e($user['username']) ?>" disabled><small>ชื่อผู้ใช้ไม่สามารถเปลี่ยนแปลงได้</small></label>
<label>ชื่อ-นามสกุล<input name="full_name" autocomplete="name" required maxlength="100" value="<?= e($data['full_name']) ?>"></label>
<div class="form-row"><label>อีเมล<input type="email" name="email" autocomplete="email" required maxlength="190" value="<?= e($data['email']) ?>"></label><label>เบอร์โทรศัพท์<input type="tel" name="phone" autocomplete="tel" required pattern="[0-9]{9,10}" maxlength="10" value="<?= e($data['phone']) ?>"></label></div>
<fieldset class="address-fields" style="border:0;padding:0;margin:0;min-width:0"><legend style="font-weight:600;margin-bottom:12px">ที่อยู่ติดต่อ</legend>
<p class="subtle">หากกรอกที่อยู่ กรุณาระบุบ้านเลขที่ ตำบล อำเภอ จังหวัด และรหัสไปรษณีย์ ส่วนหมู่บ้านและถนนเว้นว่างได้</p>
<?php if(!$savedAddress && !empty($user['address'])): ?><p class="notice">ที่อยู่เดิม: <?= e($user['address']) ?><br>กรอกแยกช่องเพื่อปรับปรุงที่อยู่ หากยังไม่กรอก ระบบจะเก็บที่อยู่เดิมไว้</p><?php endif; ?>
<div class="form-row"><?php foreach($addressFields as $key=>$spec): ?><label><?= e($spec[0]) ?><input name="<?= $key ?>" maxlength="<?= $spec[1] ?>" value="<?= e($data[$key]) ?>" <?= $key==='postal_code'?'inputmode="numeric" pattern="[0-9]{5}" autocomplete="postal-code"':'' ?>></label><?php endforeach; ?></div></fieldset>
<button class="button" type="submit">บันทึกข้อมูล ↗</button></form></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
