<?php
require __DIR__ . '/includes/requests.php'; $user = require_user(); $title = 'แดชบอร์ด';
$query = 'SELECT status, COUNT(*) AS total FROM service_requests'; $params = [];
if (!is_reviewer($user)) { $query .= ' WHERE customer_id = ?'; $params[] = $user['id']; }
$stmt = db()->prepare($query . ' GROUP BY status'); $stmt->execute($params); $requestCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
require __DIR__ . '/includes/header.php';
?>
<main class="container workspace">
<div class="workspace-heading"><div><p class="eyebrow">YOUR WORKSPACE</p><h1>สวัสดี, <?= e($user['full_name']) ?></h1><p class="subtle">จัดการบัญชีและพื้นที่ทำงานของคุณ</p></div><span class="badge"><?= e(role_label($user['role'])) ?></span></div>
<section class="request-overview"><div class="overview-heading"><div><p class="eyebrow">PROJECT OVERVIEW</p><h2><?= is_reviewer($user) ? 'ภาพรวมคำขอรับเหมา' : 'งานรับเหมาของฉัน' ?></h2></div><a class="button" href="<?= is_reviewer($user) ? 'requests.php?status=pending' : 'request-new.php' ?>"><?= is_reviewer($user) ? 'ตรวจคำขอที่รอพิจารณา ↗' : '+ ส่งคำขอใหม่' ?></a></div><?php
$waiting=0;$working=0;
foreach(['pending','awaiting_deposit','payment_review'] as $key){$waiting+=(int)($requestCounts[$key]??0);}
foreach(['ready','scheduled','traveling','in_progress'] as $key){$working+=(int)($requestCounts[$key]??0);}
?>
<div class="summary-grid">
<a class="summary-card" href="requests.php"><span>คำขอทั้งหมด</span><strong><?= array_sum($requestCounts) ?></strong><small>ดูรายการทั้งหมด ↗</small></a>
<div class="summary-card"><span>รอดำเนินการ</span><strong><?= $waiting ?></strong><small>ตรวจคำขอ · มัดจำ · ตรวจสลิป</small></div>
<div class="summary-card"><span>งานระหว่างดำเนินการ</span><strong><?= $working ?></strong><small>เตรียมงานจนถึงลงมือทำ</small></div>
<a class="summary-card summary-completed" href="requests.php?status=completed"><span>เสร็จสิ้น</span><strong><?= (int)($requestCounts['completed']??0) ?></strong><small>ดูงานที่เสร็จแล้ว ↗</small></a>
</div>
<details class="status-details"><summary>ดูแยกตามสถานะ <span>9 สถานะ</span></summary><div class="status-chips"><?php foreach(request_statuses() as $status=>$label): ?><a href="requests.php?status=<?= $status ?>"><?= e($label) ?><b><?= (int)($requestCounts[$status]??0) ?></b></a><?php endforeach; ?></div></details>
</section>
<div class="dashboard-grid"><section class="panel"><p class="eyebrow">MY ACCOUNT</p><h2>ข้อมูลบัญชี</h2><dl><div><dt>ชื่อผู้ใช้</dt><dd><?= e($user['username']) ?></dd></div><div><dt>อีเมล</dt><dd><?= e($user['email']) ?></dd></div><div><dt>เบอร์โทรศัพท์</dt><dd><?= e($user['phone']) ?></dd></div><div><dt>วันที่สมัคร</dt><dd><?= e(date('d/m/Y', strtotime($user['created_at']))) ?></dd></div></dl><a class="button button-outline" href="profile.php">แก้ไขข้อมูลส่วนตัว ↗</a></section>
<section class="panel accent-panel"><p class="eyebrow">NEXT STEP</p>
<?php if ($user['role'] === 'admin'): $counts = db()->query("SELECT role, COUNT(*) AS total FROM users GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR); ?>
<h2>ภาพรวมสมาชิก</h2><div class="stats"><?php foreach (['customer', 'staff', 'admin'] as $role): ?><div><strong><?= (int) ($counts[$role] ?? 0) ?></strong><span><?= e(role_label($role)) ?></span></div><?php endforeach; ?></div><div class="workspace-actions"><a href="users.php" class="button">จัดการสิทธิ์ผู้ใช้งาน ↗</a><a href="reports.php" class="button button-outline">รายงานสรุป ↗</a><a href="job-types.php" class="button button-outline">จัดการประเภทงาน ↗</a></div>
<?php elseif ($user['role'] === 'staff'): ?>
<h2>พื้นที่สำหรับพนักงาน</h2><p>ตรวจคำขอ แจ้งค่าใช้จ่าย และตรวจหลักฐานค่ามัดจำก่อนเริ่มงาน</p><div class="workspace-actions"><a href="requests.php?status=pending" class="button button-outline">ตรวจคำขอ ↗</a><a href="payments.php?status=pending" class="button">ตรวจสลิป ↗</a></div>
<?php else: ?>
<h2>ติดตามผลได้ในที่เดียว</h2><p>ดูผลพิจารณาและค่ามัดจำในหน้าคำขอ จากนั้นแนบสลิปให้ทีมงานตรวจสอบได้</p><a href="requests.php" class="button">ดูคำขอของฉัน ↗</a>
<?php endif; ?>
</section></div><div class="version-note"><span class="orange-dot"></span> รุ่น 2.2 · สมาชิก คำขอ มัดจำ และติดตามงาน</div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
