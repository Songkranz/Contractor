<?php
require __DIR__ . '/includes/requests.php'; $user = require_user();
if ($user['role'] !== 'customer') { http_response_code(403); exit('หน้านี้สำหรับลูกค้าส่งคำขอรับบริการ'); }
$types = db()->query('SELECT id, name FROM job_types WHERE is_active = 1 ORDER BY id')->fetchAll();
$data = ['job_type_id' => '', 'title' => '', 'description' => '', 'location' => $user['address'] ?? '', 'contact_name' => $user['full_name'], 'contact_phone' => $user['phone'], 'preferred_date' => ''];
$addressFields=['house_number'=>['บ้านเลขที่',50], 'village'=>['หมู่ที่ / หมู่บ้าน',50], 'road'=>['ซอย / ถนน',100], 'subdistrict'=>['ตำบล / แขวง',100], 'district'=>['อำเภอ / เขต',100], 'province'=>['จังหวัด',100], 'postal_code'=>['รหัสไปรษณีย์',5], 'landmark'=>['จุดสังเกต / รายละเอียดเพิ่มเติม',200]];
$stmt=db()->prepare('SELECT * FROM user_addresses WHERE user_id=?');$stmt->execute([$user['id']]);$savedAddress=$stmt->fetch();
foreach($addressFields as $key=>$spec){$data[$key]=$savedAddress[$key]??'';}
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        $errors[] = 'ไฟล์รวมใหญ่เกินค่าที่เซิร์ฟเวอร์รองรับ กรุณาเลือกรูปใหม่ไม่เกิน 3 รูป รูปละ 2 MB';
    } else {
        verify_csrf();
        foreach ($data as $key => $_) { $data[$key] = post_string($key); }
        foreach($addressFields as $key=>$spec){if(mb_strlen($data[$key])>$spec[1])$errors[]=$spec[0].'ยาวเกินกำหนด';}
        foreach(['house_number','subdistrict','district','province','postal_code'] as $key){if($data[$key]==='')$errors[]='กรุณาระบุ'.$addressFields[$key][0];}
        if(!preg_match('/\A[0-9]{5}\z/',$data['postal_code']))$errors[]='รหัสไปรษณีย์ต้องเป็นตัวเลข 5 หลัก';
        $parts=[];foreach($addressFields as $key=>$spec){if($data[$key]!=='')$parts[]=$spec[0].' '.$data[$key];}
        $data['location']=implode(' ', $parts);
        $submissionKey = post_string('submission_key');
        if (!preg_match('/\A[a-f0-9]{64}\z/', $submissionKey)) { $errors[] = 'แบบฟอร์มหมดอายุ กรุณาโหลดหน้าใหม่'; }
        else {
            $previous = db()->prepare('SELECT id FROM service_requests WHERE submission_key = ? AND customer_id = ?');
            $previous->execute([$submissionKey, $user['id']]);
            if ($previousId = $previous->fetchColumn()) { redirect('request.php?id=' . $previousId); }
            if (!hash_equals($_SESSION['request_submission_key'] ?? '', $submissionKey)) { $errors[] = 'แบบฟอร์มหมดอายุ กรุณาโหลดหน้าใหม่'; }
        }
        if (!in_array($data['job_type_id'], array_map('strval', array_column($types, 'id')), true)) { $errors[] = 'กรุณาเลือกประเภทงาน'; }
        foreach (['title' => [5, 150, 'หัวข้องาน'], 'description' => [10, 5000, 'รายละเอียดงาน'], 'location' => [10, 1000, 'สถานที่ดำเนินงาน'], 'contact_name' => [2, 100, 'ชื่อผู้ติดต่อ']] as $field => [$min, $max, $label]) {
            if (mb_strlen($data[$field]) < $min || mb_strlen($data[$field]) > $max) { $errors[] = $label . 'ต้องมีความยาว ' . $min . '–' . $max . ' ตัวอักษร'; }
        }
        if (!preg_match('/\A[0-9]{9,10}\z/', $data['contact_phone'])) { $errors[] = 'เบอร์โทรศัพท์ต้องเป็นตัวเลข 9–10 หลัก'; }
        if ($data['preferred_date'] !== '') {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $data['preferred_date']);
            if (!$date || $date->format('Y-m-d') !== $data['preferred_date'] || $data['preferred_date'] < date('Y-m-d') || $data['preferred_date'] > date('Y-m-d', strtotime('+5 years'))) { $errors[] = 'วันที่สะดวกให้เริ่มงานต้องเป็นวันนี้หรือภายใน 5 ปีข้างหน้า'; }
        }
        $images = validate_request_images($errors);
        if (!$errors) {
            $savedFiles = [];
            try {
                db()->beginTransaction();
                $stmt = db()->prepare('INSERT INTO service_requests (customer_id, job_type_id, title, description, location, contact_name, contact_phone, preferred_date, submission_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$user['id'], $data['job_type_id'], $data['title'], $data['description'], $data['location'], $data['contact_name'], $data['contact_phone'], $data['preferred_date'] ?: null, $submissionKey]);
                $id = (int) db()->lastInsertId();
                if ($images && !is_dir(upload_directory()) && !mkdir(upload_directory(), 0750, true) && !is_dir(upload_directory())) { throw new RuntimeException('Cannot create image storage'); }
                foreach ($images as $image) {
                    $destination = upload_directory() . '/' . $image['name'];
                    if (!move_uploaded_file($image['tmp'], $destination)) { throw new RuntimeException('Cannot save uploaded image'); }
                    $savedFiles[] = $destination;
                    $stmt = db()->prepare('INSERT INTO request_images (request_id, storage_name, mime_type, byte_size) VALUES (?, ?, ?, ?)');
                    $stmt->execute([$id, $image['name'], $image['mime'], $image['size']]);
                }
                $stmt = db()->prepare("INSERT INTO request_status_history (request_id, actor_id, status, note) VALUES (?, ?, 'pending', 'ลูกค้าส่งคำขอรับบริการ')");
                $stmt->execute([$id, $user['id']]); db()->commit();
                unset($_SESSION['request_submission_key']); flash('ส่งคำขอเรียบร้อยแล้ว ทีมงานจะตรวจสอบรายละเอียดของคุณ'); redirect('request.php?id=' . $id);
            } catch (Throwable $exception) {
                if (db()->inTransaction()) { db()->rollBack(); }
                foreach ($savedFiles as $file) { if (is_file($file)) { unlink($file); } }
                error_log($exception->getMessage()); $errors[] = 'บันทึกคำขอไม่สำเร็จ กรุณาลองใหม่ หากแนบรูปให้เลือกไฟล์อีกครั้ง';
            }
        }
    }
}
if (empty($_SESSION['request_submission_key'])) { $_SESSION['request_submission_key'] = bin2hex(random_bytes(32)); }
$title = 'ส่งคำขอรับเหมา'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="requests.php">← คำขอของฉัน</a><div class="workspace-heading"><div><p class="eyebrow">START YOUR PROJECT</p><h1>เล่าเรื่องพื้นที่ของคุณ</h1><p class="subtle">บอกรายละเอียดงานที่ต้องการ เพื่อให้ทีมงานประเมินได้ตรงจุด</p></div><span class="badge">คำขอใหม่</span></div>
<div class="request-layout"><section class="form-card">
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach (array_unique($errors) as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul><p>หากแนบรูปไว้ กรุณาเลือกรูปอีกครั้งก่อนส่ง</p></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="stack-form" data-request-form><?= csrf() ?><input type="hidden" name="submission_key" value="<?= e($_SESSION['request_submission_key']) ?>">
<div class="form-section-title"><span>01</span><h2>รายละเอียดงาน</h2></div>
<label>ประเภทงาน <span class="required">จำเป็น</span><select name="job_type_id" required><option value="">เลือกประเภทงาน</option><?php foreach ($types as $type): ?><option value="<?= (int) $type['id'] ?>" <?= (string) $type['id'] === $data['job_type_id'] ? 'selected' : '' ?>><?= e($type['name']) ?></option><?php endforeach; ?></select></label>
<label>หัวข้องาน<input name="title" required minlength="5" maxlength="150" value="<?= e($data['title']) ?>" placeholder="เช่น ต่อเติมห้องครัวหลังบ้าน"></label>
<label>รายละเอียดงาน<textarea name="description" required minlength="10" maxlength="5000" rows="5" placeholder="บอกลักษณะงาน ขนาดพื้นที่โดยประมาณ และสิ่งที่ต้องการให้ทีมงานช่วยดูแล"><?= e($data['description']) ?></textarea><small>10–5,000 ตัวอักษร</small></label>
<label>วันที่สะดวกให้เริ่มงาน (ไม่บังคับ)<input type="date" name="preferred_date" min="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d', strtotime('+5 years')) ?>" value="<?= e($data['preferred_date']) ?>"><small>เป็นวันที่เสนอให้ทีมงานพิจารณา ยังไม่ใช่การยืนยันนัดหมาย</small></label>
<div class="form-section-title"><span>02</span><h2>สถานที่และผู้ติดต่อ</h2></div>
<fieldset style="border:0;padding:0;margin:0;min-width:0"><legend style="font-weight:600;margin-bottom:12px">สถานที่ดำเนินงาน</legend><p class="subtle">กรอกที่อยู่หน้างานจริง สามารถแก้ไขจากที่อยู่โปรไฟล์ได้</p>
<?php if(!$savedAddress && !empty($user['address'])): ?><p class="notice">ที่อยู่เดิมสำหรับอ้างอิง: <?= e($user['address']) ?><br>กรุณากรอกที่อยู่แยกช่องด้านล่าง</p><?php endif; ?>
<div class="form-row"><?php foreach($addressFields as $key=>$spec): $required=in_array($key,['house_number','subdistrict','district','province','postal_code'],true); ?><label><?= e($spec[0]) ?><?= $required?' *':' (ไม่บังคับ)' ?><input name="<?= $key ?>" maxlength="<?= $spec[1] ?>" value="<?= e($data[$key]) ?>" <?= $required?'required':'' ?> <?= $key==='postal_code'?'inputmode="numeric" pattern="[0-9]{5}"':'' ?>></label><?php endforeach; ?></div></fieldset>
<div class="form-row"><label>ชื่อผู้ติดต่อ<input name="contact_name" autocomplete="name" required minlength="2" maxlength="100" value="<?= e($data['contact_name']) ?>"></label><label>เบอร์โทรศัพท์<input name="contact_phone" type="tel" autocomplete="tel" required pattern="[0-9]{9,10}" maxlength="10" value="<?= e($data['contact_phone']) ?>"></label></div>
<div class="form-section-title"><span>03</span><h2>ภาพประกอบ</h2></div>
<label class="upload-field">แนบรูปสถานที่หรือตัวอย่างงาน (ไม่บังคับ)<input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp" data-image-input aria-describedby="image-help"><small id="image-help">JPG, PNG หรือ WebP สูงสุด 3 รูป รูปละไม่เกิน 2 MB</small></label><p class="file-feedback subtle" data-file-feedback role="status"></p>
<button class="button full-width" type="submit" data-submit-request>ส่งคำขอให้ทีมงานตรวจสอบ ↗</button>
</form></section><aside class="request-aside"><section class="panel accent-panel"><p class="eyebrow">WHAT HAPPENS NEXT</p><h2>จากคำขอ<br>สู่การเริ่มงาน</h2><ol class="steps-list"><li><strong>ส่งรายละเอียดงาน</strong><span>แนบข้อมูลและรูปเพื่อประกอบการพิจารณา</span></li><li><strong>ทีมงานตรวจสอบ</strong><span>พิจารณาความเหมาะสมและระบุค่าใช้จ่าย</span></li><li><strong>ติดตามผลในระบบ</strong><span>ดูผลอนุมัติและจำนวนค่ามัดจำจากหน้าคำขอ</span></li></ol></section><p class="subtle aside-note">รูปและรายละเอียดคำขอเข้าถึงได้เฉพาะคุณและทีมงานที่มีสิทธิ์</p></aside></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
