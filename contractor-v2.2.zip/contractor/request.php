<?php
require __DIR__ . '/includes/payments.php'; $user = require_user();
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$request = request_for_user($id, $user); $errors = [];
$review = ['decision' => 'approve', 'quoted_total' => '', 'deposit_amount' => '', 'cost_details' => '', 'review_note' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_reviewer($user)) { http_response_code(403); exit('คุณไม่มีสิทธิ์พิจารณาคำขอ'); }
    verify_csrf();
    foreach ($review as $key => $_) { $review[$key] = post_string($key); }
    if (!in_array($review['decision'], ['approve', 'reject'], true)) { $errors[] = 'กรุณาเลือกผลพิจารณาให้ถูกต้อง'; }
    if (mb_strlen($review['review_note']) > 3000) { $errors[] = 'หมายเหตุต้องไม่เกิน 3,000 ตัวอักษร'; }
    $totalCents = money_cents($review['quoted_total']); $depositCents = money_cents($review['deposit_amount']);
    if ($review['decision'] === 'approve') {
        if ($totalCents === null || $totalCents <= 0) { $errors[] = 'ค่าใช้จ่ายรวมต้องมากกว่า 0 และไม่เกิน 99,999,999.99 บาท ใช้ทศนิยมไม่เกิน 2 ตำแหน่ง'; }
        if ($depositCents === null || ($totalCents !== null && $depositCents > $totalCents)) { $errors[] = 'ค่ามัดจำต้องเป็น 0 หรือจำนวนไม่เกินค่าใช้จ่ายรวม ใช้ทศนิยมไม่เกิน 2 ตำแหน่ง'; }
        if (mb_strlen($review['cost_details']) < 5 || mb_strlen($review['cost_details']) > 3000) { $errors[] = 'กรุณาระบุรายละเอียดค่าใช้จ่าย 5–3,000 ตัวอักษร'; }
    } elseif ($review['decision'] === 'reject' && mb_strlen($review['review_note']) < 5) { $errors[] = 'กรุณาระบุเหตุผลที่ไม่อนุมัติอย่างน้อย 5 ตัวอักษร'; }
    if ($request['status'] !== 'pending') { $errors[] = 'คำขอนี้ได้รับการพิจารณาแล้ว ไม่สามารถบันทึกซ้ำได้'; }
    if (!$errors) {
        try {
            db()->beginTransaction();
            $lock = db()->prepare('SELECT status FROM service_requests WHERE id = ? FOR UPDATE'); $lock->execute([$id]);
            if ($lock->fetchColumn() !== 'pending') {
                db()->rollBack(); $errors[] = 'มีพนักงานพิจารณาคำขอนี้แล้ว กรุณาตรวจสอบผลล่าสุดด้านล่าง';
            } else {
                $approved = $review['decision'] === 'approve';
                $status = $approved ? ($depositCents > 0 ? 'awaiting_deposit' : 'ready') : 'rejected';
                $stmt = db()->prepare('UPDATE service_requests SET status = ?, quoted_total = ?, deposit_amount = ?, cost_details = ?, review_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?');
                $stmt->execute([$status, $approved ? decimal_money($totalCents) : null, $approved ? decimal_money($depositCents) : null, $approved ? $review['cost_details'] : null, $review['review_note'] ?: null, $user['id'], $id]);
                $note = $approved ? 'อนุมัติคำขอ ค่าใช้จ่ายรวม ' . money(decimal_money($totalCents)) . ' ค่ามัดจำ ' . money(decimal_money($depositCents)) : 'ไม่อนุมัติคำขอ: ' . $review['review_note'];
                $stmt = db()->prepare('INSERT INTO request_status_history (request_id, actor_id, status, note) VALUES (?, ?, ?, ?)'); $stmt->execute([$id, $user['id'], $status, $note]);
                db()->commit(); flash('บันทึกผลพิจารณาแล้ว ลูกค้าดูผลได้จากหน้าคำขอของตนเอง'); redirect('request.php?id=' . $id);
            }
        } catch (Throwable $exception) {
            if (db()->inTransaction()) { db()->rollBack(); }
            error_log($exception->getMessage()); $errors[] = 'บันทึกผลไม่สำเร็จ กรุณาลองใหม่';
        }
        $request = request_for_user($id, $user);
    }
}
$stmt = db()->prepare('SELECT id FROM request_images WHERE request_id = ? ORDER BY id'); $stmt->execute([$id]); $images = $stmt->fetchAll();
$stmt = db()->prepare('SELECT h.*, u.full_name AS actor_name FROM request_status_history h JOIN users u ON u.id = h.actor_id WHERE h.request_id = ? ORDER BY h.id DESC'); $stmt->execute([$id]); $history = $stmt->fetchAll();
$title = request_number($id); require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="requests.php">← กลับรายการคำขอ</a><div class="workspace-heading"><div><p class="eyebrow"><?= request_number($id) ?> · <?= e($request['job_type']) ?></p><h1><?= e($request['title']) ?></h1><p class="subtle">ส่งเมื่อ <?= e(short_date($request['created_at'])) ?></p></div><span class="status-badge status-<?= e($request['status']) ?>"><?= e(status_label($request['status'])) ?></span></div>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="request-layout"><div class="detail-stack"><section class="panel"><p class="eyebrow">PROJECT BRIEF</p><h2>รายละเอียดงาน</h2><p class="preserve-lines"><?= e($request['description']) ?></p><hr class="divider"><h3>สถานที่ดำเนินงาน</h3><p class="preserve-lines"><?= e($request['location']) ?></p><dl><div><dt>ผู้ติดต่อ</dt><dd><?= e($request['contact_name']) ?></dd></div><div><dt>โทรศัพท์</dt><dd><a href="tel:<?= e($request['contact_phone']) ?>"><?= e($request['contact_phone']) ?></a></dd></div><div><dt>วันที่สะดวก</dt><dd><?= $request['preferred_date'] ? e(date('d/m/Y', strtotime($request['preferred_date']))) . ' (รอยืนยันนัดหมาย)' : 'ให้ทีมงานติดต่อเพื่อนัดหมาย' ?></dd></div></dl>
<h3>รูปประกอบ <span class="subtle">(<?= count($images) ?> รูป)</span></h3><?php if ($images): ?><div class="attachment-grid"><?php foreach ($images as $index => $image): ?><a href="request-image.php?id=<?= (int) $image['id'] ?>" target="_blank" rel="noopener"><img src="request-image.php?id=<?= (int) $image['id'] ?>" alt="ภาพประกอบคำขอ รูปที่ <?= $index + 1 ?>" loading="lazy"><span>เปิดรูปที่ <?= $index + 1 ?> ↗</span></a><?php endforeach; ?></div><?php else: ?><p class="subtle">ลูกค้าไม่ได้แนบรูปประกอบ</p><?php endif; ?></section>
<?php if ($request['status'] !== 'pending'): ?><section class="panel"><p class="eyebrow">REVIEW RESULT</p><h2><?= $request['status'] === 'rejected' ? 'ผลพิจารณา: ไม่อนุมัติ' : 'คำขอของคุณได้รับอนุมัติแล้ว' ?></h2>
<?php if ($request['status'] !== 'rejected'): ?><div class="quote-summary"><div><span>ค่าใช้จ่ายรวมที่แจ้ง</span><strong><?= money($request['quoted_total']) ?></strong></div><div><span>ค่ามัดจำ</span><strong><?= money($request['deposit_amount']) ?></strong></div></div><h3>รายละเอียดค่าใช้จ่าย</h3><p class="preserve-lines"><?= e($request['cost_details']) ?></p><?php if (money_cents($request['deposit_amount'] ?? '') === 0): ?><p class="notice">งานนี้ไม่เรียกเก็บค่ามัดจำ</p><?php endif; ?><?php endif; ?>
<?php if ($request['review_note']): ?><h3><?= $request['status'] === 'rejected' ? 'เหตุผลที่ไม่อนุมัติ' : 'หมายเหตุจากทีมงาน' ?></h3><p class="preserve-lines"><?= e($request['review_note']) ?></p><?php endif; ?>
<p class="subtle">พิจารณาโดย <?= e($request['reviewer_name']) ?> · <?= e(short_date($request['reviewed_at'])) ?></p></section><?php endif; ?>
<?php require __DIR__ . '/includes/progress-section.php'; ?>
<?php require __DIR__ . '/includes/payment-section.php'; require __DIR__ . '/includes/completion-section.php'; ?>
<?php if (is_reviewer($user) && $request['status'] === 'pending'): ?><section class="form-card" id="review"><p class="eyebrow">STAFF REVIEW</p><h2>พิจารณาคำขอ</h2><p class="subtle">ผลพิจารณาและค่าใช้จ่ายจะแสดงให้ลูกค้าเห็นหลังบันทึก</p><form method="post" class="stack-form" data-review-form><?= csrf() ?>
<label>ผลพิจารณา<select name="decision" data-decision><option value="approve" <?= $review['decision'] !== 'reject' ? 'selected' : '' ?>>อนุมัติคำขอ</option><option value="reject" <?= $review['decision'] === 'reject' ? 'selected' : '' ?>>ไม่อนุมัติคำขอ</option></select></label>
<div data-quote-fields class="stack-form"><div class="form-row"><label>ค่าใช้จ่ายรวม (บาท)<input type="number" name="quoted_total" min="0.01" max="99999999.99" step="0.01" value="<?= e($review['quoted_total']) ?>" placeholder="เช่น 25000.00" data-approval-required></label><label>ค่ามัดจำ (บาท)<input type="number" name="deposit_amount" min="0" max="99999999.99" step="0.01" value="<?= e($review['deposit_amount']) ?>" placeholder="เช่น 5000.00" data-approval-required><small>ไม่เกินค่าใช้จ่ายรวม ใส่ 0 หากไม่เก็บมัดจำ</small></label></div><label>รายละเอียดค่าใช้จ่าย<textarea name="cost_details" minlength="5" maxlength="3000" rows="4" placeholder="เช่น ค่าแรง 15,000 บาท ค่าวัสดุ 10,000 บาท รวม 25,000 บาท" data-approval-required><?= e($review['cost_details']) ?></textarea></label></div>
<label><span data-note-label>หมายเหตุ / เหตุผลที่ไม่อนุมัติ</span><textarea name="review_note" maxlength="3000" rows="3" data-review-note placeholder="ข้อมูลที่ต้องการแจ้งลูกค้า"><?= e($review['review_note']) ?></textarea></label><p class="subtle">ตรวจสอบข้อมูลก่อนบันทึก ผลพิจารณาที่บันทึกแล้วจะไม่สามารถแก้ไขในรุ่นนี้</p><button class="button" type="submit">บันทึกผลพิจารณา ↗</button></form></section><?php endif; ?>
</div><aside class="request-aside"><section class="panel"><p class="eyebrow">REQUEST TIMELINE</p><h2>ประวัติคำขอ</h2><ol class="timeline"><?php foreach ($history as $event): ?><li><span class="timeline-dot"></span><strong><?= e(status_label($event['status'])) ?></strong><p class="preserve-lines"><?= e($event['note']) ?></p><small><?= e($event['actor_name']) ?><br><?= e(short_date($event['created_at'])) ?></small></li><?php endforeach; ?></ol></section><?php if ($request['status'] === 'pending'): ?><section class="panel accent-panel"><h3>อยู่ระหว่างรอพิจารณา</h3><p class="subtle"><?= is_reviewer($user) ? 'ตรวจรายละเอียดและรูปประกอบให้ครบก่อนระบุค่าใช้จ่ายและผลพิจารณา' : 'ทีมงานจะตรวจรายละเอียดของคุณ สามารถกลับมาดูผลได้ที่หน้านี้' ?></p></section><?php endif; ?></aside></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
