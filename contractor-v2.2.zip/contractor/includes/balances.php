<?php
declare(strict_types=1);
require_once __DIR__ . '/requests.php';

function balance_statuses(): array { return ['pending' => 'รอตรวจสอบ', 'approved' => 'อนุมัติสลิปแล้ว', 'rejected' => 'หลักฐานไม่ผ่าน']; }
function balance_label(string $status): string { return balance_statuses()[$status] ?? $status; }
function balance_number(int $id): string { return 'BAL-' . str_pad((string) $id, 5, '0', STR_PAD_LEFT); }
function balance_directory(): string
{
    $config = require __DIR__ . '/../config.php';
    return rtrim($config['payment_upload_dir'], '/\\');
}
function balance_for_user(int $id, array $user): array
{
    $sql = "SELECT p.*, r.title AS request_title, r.customer_id, r.status AS request_status, (r.quoted_total-COALESCE((SELECT SUM(amount) FROM deposit_payments WHERE request_id=r.id AND status='approved'),0)) AS deposit_amount, u.full_name AS customer_name, reviewer.full_name AS reviewer_name FROM balance_payments p JOIN service_requests r ON r.id = p.request_id JOIN users u ON u.id = p.submitted_by LEFT JOIN users reviewer ON reviewer.id = p.reviewed_by WHERE p.id = ?";
    $params = [$id];
    if (!is_reviewer($user)) { $sql .= ' AND r.customer_id = ?'; $params[] = $user['id']; }
    $stmt = db()->prepare($sql); $stmt->execute($params); $payment = $stmt->fetch();
    if (!$payment) { http_response_code(404); exit('ไม่พบหลักฐานที่คุณเข้าถึงได้'); }
    return $payment;
}
