<?php
$stmt = db()->prepare('SELECT * FROM job_progress WHERE request_id = ?'); $stmt->execute([$id]); $jobProgress = $stmt->fetch();
$workStatuses = ['ready','scheduled','traveling','in_progress','completed'];
?>
<?php if (in_array($request['status'], $workStatuses, true)): ?><section class="panel"><p class="eyebrow">WORK PROGRESS</p><h2>ความคืบหน้าการทำงาน</h2><p><span class="status-badge status-<?= e($request['status']) ?>"><?= e(status_label($request['status'])) ?></span></p>
<?php if ($jobProgress): ?><dl><div><dt>นัดหมาย</dt><dd><?= e(short_date($jobProgress['appointment_at'])) ?></dd></div><?php if ($jobProgress['arrival_at']): ?><div><dt>คาดว่าจะถึง</dt><dd><?= e(short_date($jobProgress['arrival_at'])) ?></dd></div><?php endif; ?><?php if ($jobProgress['completed_at']): ?><div><dt>เสร็จสิ้นเมื่อ</dt><dd><?= e(short_date($jobProgress['completed_at'])) ?></dd></div><?php endif; ?></dl><?php else: ?><p class="subtle">รอทีมงานกำหนดวันและเวลานัดหมาย</p><?php endif; ?>
<?php if (is_reviewer($user) && $request['status'] !== 'completed'): ?><a class="button" href="progress.php?id=<?= $id ?>">อัปเดตสถานะ / นัดหมาย ↗</a><?php endif; ?><p class="subtle">ดูรายละเอียดการอัปเดตและผู้ดำเนินการได้ในประวัติคำขอ</p></section><?php endif; ?>
