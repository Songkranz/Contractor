<?php
function notification_scope(array $user): array {
 $scope='h.actor_id <> ?';$params=[$user['id']];
 if($user['role']==='customer'){$scope.=' AND r.customer_id=?';$params[]=$user['id'];}
 return [$scope,$params];
}
function unread_notifications(array $user): int {
 [$scope,$params]=notification_scope($user);
 $stmt=db()->prepare('SELECT COUNT(*) FROM request_status_history h JOIN service_requests r ON r.id=h.request_id LEFT JOIN notification_reads n ON n.history_id=h.id AND n.user_id=? WHERE n.history_id IS NULL AND '.$scope);
 $stmt->execute(array_merge([$user['id']],$params));return (int)$stmt->fetchColumn();
}
