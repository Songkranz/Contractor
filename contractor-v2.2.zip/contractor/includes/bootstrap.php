<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
session_name('contractor_session');
session_set_cookie_params([
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
header('Cache-Control: no-store');

function db(): PDO
{
    static $pdo;
    if (!$pdo) {
        $config = require __DIR__ . '/../config.php';
        try {
            $pdo = new PDO(
                'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
                $config['db_user'], $config['db_pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
            );
        } catch (PDOException $e) {
            error_log($e->getMessage());
            http_response_code(503);
            exit('ยังเชื่อมต่อฐานข้อมูลไม่ได้ กรุณาเปิด MySQL และตรวจสอบ config.php ตามคู่มือ README.md');
        }
    }
    return $pdo;
}

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect(string $path): void { header('Location: ' . $path); exit; }
function csrf(): string
{
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function verify_csrf(): void
{
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']) || empty($_SESSION['csrf'])) {
        http_response_code(403);
        exit('คำขอหมดอายุหรือไม่ถูกต้อง กรุณากลับไปโหลดหน้าใหม่');
    }
}
function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) { return null; }
    $stmt = db()->prepare('SELECT id, username, full_name, email, phone, address, role, created_at FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}
function require_user(): array
{
    $user = current_user();
    if (!$user) { redirect('login.php'); }
    return $user;
}
function require_admin(): array
{
    $user = require_user();
    if ($user['role'] !== 'admin') { http_response_code(403); exit('คุณไม่มีสิทธิ์เข้าถึงหน้านี้'); }
    return $user;
}
function role_label(string $role): string
{
    return ['customer' => 'ลูกค้า', 'staff' => 'พนักงาน', 'admin' => 'ผู้ดูแลระบบ'][$role] ?? $role;
}
function flash(string $message): void { $_SESSION['flash'] = $message; }
function post_string(string $key): string { return is_string($_POST[$key] ?? null) ? trim($_POST[$key]) : ''; }
