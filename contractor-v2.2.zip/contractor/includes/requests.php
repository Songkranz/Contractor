<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
date_default_timezone_set('Asia/Bangkok');
db()->exec("SET time_zone = '+07:00'");

function is_reviewer(array $user): bool { return in_array($user['role'], ['staff', 'admin'], true); }
function request_statuses(): array
{
    return ['pending' => 'รอตรวจสอบ', 'awaiting_deposit' => 'รอชำระค่ามัดจำ', 'payment_review' => 'รอตรวจสลิป', 'ready' => 'เตรียมดำเนินงาน', 'scheduled' => 'นัดหมายแล้ว', 'traveling' => 'กำลังเดินทาง', 'in_progress' => 'กำลังดำเนินงาน', 'completed' => 'เสร็จสิ้น', 'rejected' => 'ไม่อนุมัติ'];
}
function status_label(string $status): string { return request_statuses()[$status] ?? $status; }
function request_number(int $id): string { return 'RQ-' . str_pad((string) $id, 5, '0', STR_PAD_LEFT); }
function money(?string $amount): string { return $amount === null ? 'ยังไม่ระบุ' : number_format((float) $amount, 2) . ' บาท'; }
function money_cents(string $value): ?int
{
    if (!preg_match('/\A(?:0|[1-9][0-9]{0,7})(?:\.[0-9]{1,2})?\z/', $value)) { return null; }
    $parts = explode('.', $value);
    return (int) $parts[0] * 100 + (int) str_pad($parts[1] ?? '', 2, '0');
}
function decimal_money(int $cents): string { return intdiv($cents, 100) . '.' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT); }
function short_date(string $date): string { return date('d/m/Y H:i', strtotime($date)); }
function request_for_user(int $id, array $user): array
{
    $sql = 'SELECT r.*, t.name AS job_type, u.full_name AS customer_name, reviewer.full_name AS reviewer_name FROM service_requests r JOIN job_types t ON t.id = r.job_type_id JOIN users u ON u.id = r.customer_id LEFT JOIN users reviewer ON reviewer.id = r.reviewed_by WHERE r.id = ?';
    $params = [$id];
    if (!is_reviewer($user)) { $sql .= ' AND r.customer_id = ?'; $params[] = $user['id']; }
    $stmt = db()->prepare($sql); $stmt->execute($params); $request = $stmt->fetch();
    if (!$request) { http_response_code(404); exit('ไม่พบคำขอที่คุณเข้าถึงได้'); }
    return $request;
}
function upload_directory(): string
{
    $config = require __DIR__ . '/../config.php';
    return rtrim($config['upload_dir'], '/\\');
}
function validate_request_images(array &$errors, string $field = 'images', int $maxFiles = 3): array
{
    $files = $_FILES[$field] ?? null;
    if (!$files) { return []; }
    if (!is_array($files['error'] ?? null)) { $errors[] = 'รูปแบบไฟล์แนบไม่ถูกต้อง'; return []; }
    $indices = array_keys(array_filter($files['error'], fn($error) => $error !== UPLOAD_ERR_NO_FILE));
    if (count($indices) > $maxFiles) { $errors[] = 'แนบรูปภาพได้ไม่เกิน ' . $maxFiles . ' รูป'; return []; }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $validated = [];
    foreach ($indices as $index) {
        if ($files['error'][$index] !== UPLOAD_ERR_OK) { $errors[] = 'อัปโหลดรูปไม่สำเร็จ โปรดเลือกไฟล์ใหม่ (ไม่เกิน 2 MB ต่อรูป)'; continue; }
        $tmp = $files['tmp_name'][$index] ?? null;
        if (!is_string($tmp) || !is_uploaded_file($tmp)) { $errors[] = 'ไฟล์แนบไม่ถูกต้อง'; continue; }
        $size = filesize($tmp);
        if (!$size || $size > 2 * 1024 * 1024) { $errors[] = 'รูปภาพแต่ละรูปต้องมีขนาดไม่เกิน 2 MB'; continue; }
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
        $dimensions = @getimagesize($tmp);
        if (!isset($allowed[$mime]) || !$dimensions || ($dimensions['mime'] ?? '') !== $mime) { $errors[] = 'รองรับเฉพาะไฟล์รูปภาพ JPG, PNG หรือ WebP เท่านั้น'; continue; }
        if ($dimensions[0] > 12000 || $dimensions[1] > 12000 || $dimensions[0] * $dimensions[1] > 40000000) { $errors[] = 'รูปภาพมีความละเอียดสูงเกินไป กรุณาย่อรูปก่อน'; continue; }
        $validated[] = ['tmp' => $tmp, 'mime' => $mime, 'size' => $size, 'name' => bin2hex(random_bytes(24)) . '.' . $allowed[$mime]];
    }
    return $validated;
}
