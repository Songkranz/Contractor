<?php
// Included by request.php after it has verified access to this request.
$paymentStmt = db()->prepare('SELECT id, amount, status, review_note, created_at FROM deposit_payments WHERE request_id = ? ORDER BY id DESC LIMIT 20');
$paymentStmt->execute([$id]); $requestPayments = $paymentStmt->fetchAll();
?>
<?php if ($request['deposit_amount'] !== null && money_cents($request['deposit_amount']) > 0): ?>
<section class="panel" id="deposit"><p class="eyebrow">DEPOSIT EVIDENCE</p><h2>หลักฐานค่ามัดจำ</h2>
<?php if ($request['status'] === 'awaiting_deposit'): ?>
<?php if ($requestPayments && $requestPayments[0]['status'] === 'rejected'): ?><div class="alert error"><strong>หลักฐานล่าสุดไม่ผ่าน</strong><p class="preserve-lines"><?= e($requestPayments[0]['review_note']) ?></p></div><?php endif; ?>
<?php if ($user['role'] === 'customer'): ?><p>แนบภาพสลิปยอด <?= money($request['deposit_amount']) ?> เพื่อให้ทีมงานตรวจสอบ</p><a class="button" href="payment-new.php?request_id=<?= $id ?>"><?= $requestPayments ? 'ส่งหลักฐานใหม่' : 'แจ้งชำระค่ามัดจำ / แนบสลิป' ?> ↗</a><?php else: ?><p class="subtle">รอลูกค้าแนบหลักฐานค่ามัดจำ <?= money($request['deposit_amount']) ?></p><?php endif; ?>
<?php elseif ($request['status'] === 'payment_review'): ?><p class="notice">ได้รับสลิปแล้ว อยู่ระหว่างรอทีมงานตรวจสอบ</p>
<?php elseif (in_array($request['status'], ['ready','scheduled','traveling','in_progress','completed'], true)): ?><p class="alert success">ทีมงานอนุมัติหลักฐานค่ามัดจำแล้ว</p><?php endif; ?>
<?php if ($requestPayments): ?><div class="payment-history"><?php foreach ($requestPayments as $deposit): ?><a class="payment-history-item" href="payment.php?id=<?= (int) $deposit['id'] ?>"><span><strong><?= payment_number((int) $deposit['id']) ?></strong><small><?= e(short_date($deposit['created_at'])) ?> · <?= money($deposit['amount']) ?></small></span><span class="payment-badge payment-<?= e($deposit['status']) ?>"><?= e(payment_label($deposit['status'])) ?> ↗</span></a><?php endforeach; ?></div><a class="text-link" href="payments.php?q=<?= request_number($id) ?>">ดูประวัติหลักฐานทั้งหมด →</a><?php endif; ?></section>
<?php endif; ?>
