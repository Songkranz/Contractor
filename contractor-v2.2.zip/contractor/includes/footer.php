<footer class="site-footer"><a class="footer-brand" href="index.php">ซาเล็ง กรุ๊ป<span> งานรับเหมาอิสระ</span></a><p>โครงงานระบบสารสนเทศ · บุรีรัมย์</p><span>© <?= date('Y') ?> SALE NG GROUP</span></footer>
</body>
</html>
