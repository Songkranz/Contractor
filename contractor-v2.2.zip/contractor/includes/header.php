<?php require_once __DIR__.'/notifications.php'; $navUser = current_user(); ?>
<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'ซาเล็ง กรุ๊ป') ?> | งานรับเหมาอิสระ</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/requests.css?v=1.3">
    <link rel="stylesheet" href="assets/payments.css?v=1.3">
    <link rel="stylesheet" href="assets/modern.css?v=1.9">
    <script src="assets/app.js?v=1.9" defer></script>
</head>
<body>
<header class="site-header">
    <a class="brand" href="index.php"><span class="brand-mark">S<span>.</span></span><span>ซาเล็ง กรุ๊ป<small>SALE NG GROUP / CONTRACTOR</small></span></a>
    <nav aria-label="เมนูหลัก">
        <a href="index.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'index.php' ? 'aria-current="page"' : '' ?>>หน้าแรก</a>
        <?php if ($navUser): ?>
            <a href="dashboard.php">แดชบอร์ด</a>
            <a href="requests.php"><?= $navUser['role'] === 'customer' ? 'คำขอของฉัน' : 'ตรวจคำขอ' ?></a>
            <details class="nav-dropdown"><summary>การชำระเงิน</summary><div class="nav-dropdown-menu"><a href="payments.php">สลิปมัดจำ</a><a href="balances.php">ยอดคงเหลือ</a></div></details>
            <a href="notifications.php" class="notification-link">แจ้งเตือน <span class="nav-count"><?= unread_notifications($navUser) ?></span></a>
            <details class="nav-dropdown"><summary>บัญชีของฉัน</summary><div class="nav-dropdown-menu"><a href="profile.php">ข้อมูลส่วนตัว</a><?php if($navUser['role']==='admin'): ?><a href="reports.php">รายงานสรุป</a><a href="job-types.php">ประเภทงาน</a><a href="users.php">ผู้ใช้งาน</a><?php endif; ?><form action="logout.php" method="post"><?= csrf() ?><button type="submit">ออกจากระบบ</button></form></div></details>
        <?php else: ?>
            <a href="login.php">เข้าสู่ระบบ</a>
            <a class="button button-small" href="register.php">สมัครสมาชิก <span aria-hidden="true">↗</span></a>
        <?php endif; ?>
    </nav>
</header>
<?php if (isset($_SESSION['flash'])): ?><div class="container"><div class="alert success" role="status"><?= e($_SESSION['flash']) ?></div></div><?php unset($_SESSION['flash']); endif; ?>
