<?php
declare(strict_types=1);
require_once __DIR__ . '/requests.php';

function payment_statuses(): array { return ['pending' => 'รอตรวจสอบ', 'approved' => 'อนุมัติสลิปแล้ว', 'rejected' => 'หลักฐานไม่ผ่าน']; }
function payment_label(string $status): string { return payment_statuses()[$status] ?? $status; }
function payment_number(int $id): string { return 'PAY-' . str_pad((string) $id, 5, '0', STR_PAD_LEFT); }
function payment_directory(): string
{
    $config = require __DIR__ . '/../config.php';
    return rtrim($config['payment_upload_dir'], '/\\');
}
function payment_for_user(int $id, array $user): array
{
    $sql = 'SELECT p.*, r.title AS request_title, r.customer_id, r.status AS request_status, r.deposit_amount, u.full_name AS customer_name, reviewer.full_name AS reviewer_name FROM deposit_payments p JOIN service_requests r ON r.id = p.request_id JOIN users u ON u.id = p.submitted_by LEFT JOIN users reviewer ON reviewer.id = p.reviewed_by WHERE p.id = ?';
    $params = [$id];
    if (!is_reviewer($user)) { $sql .= ' AND r.customer_id = ?'; $params[] = $user['id']; }
    $stmt = db()->prepare($sql); $stmt->execute($params); $payment = $stmt->fetch();
    if (!$payment) { http_response_code(404); exit('ไม่พบหลักฐานที่คุณเข้าถึงได้'); }
    return $payment;
}
