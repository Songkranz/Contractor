<?php
require_once __DIR__.'/balances.php';
if($request['status']==='completed'):
$stmt=db()->prepare("SELECT COALESCE(SUM(amount),0) FROM deposit_payments WHERE request_id=? AND status='approved'");$stmt->execute([$id]);$paid=money_cents((string)$stmt->fetchColumn())??0;
$remaining=max(0,(money_cents($request['quoted_total']??'0')??0)-$paid);
$stmt=db()->prepare('SELECT * FROM balance_payments WHERE request_id=? ORDER BY id DESC');$stmt->execute([$id]);$balances=$stmt->fetchAll();
$blocked=false;$settled=$remaining===0;foreach($balances as $b){if(in_array($b['status'],['pending','approved'],true))$blocked=true;if($b['status']==='approved')$settled=true;}
$stmt=db()->prepare('SELECT id FROM completion_images WHERE request_id=? ORDER BY id');$stmt->execute([$id]);$photos=$stmt->fetchAll();
?>
<section class="panel"><h2>ภาพผลงานเมื่อปิดงาน</h2><?php if(!$photos): ?><p class="subtle">ยังไม่มีภาพผลงาน</p><?php endif; ?><div class="request-stats"><?php foreach($photos as $photo): ?><a href="completion-image.php?id=<?= (int)$photo['id'] ?>" target="_blank" rel="noopener"><img src="completion-image.php?id=<?= (int)$photo['id'] ?>" alt="ภาพผลงาน" style="width:100%;max-height:240px;object-fit:contain"></a><?php endforeach; ?></div><?php if(is_reviewer($user)&&count($photos)<3): ?><a class="button" href="completion.php?id=<?= $id ?>">แนบภาพผลงาน ↗</a><?php endif; ?></section>
<section class="panel"><h2>การชำระยอดคงเหลือ</h2><p>ราคางาน <?= money($request['quoted_total']) ?> · มัดจำที่อนุมัติ <?= money(decimal_money($paid)) ?></p><p class="<?= $settled?'alert success':'notice' ?>"><?= $settled?'ชำระครบแล้ว':'ยอดคงเหลือ '.money(decimal_money($remaining)) ?></p><?php if(!$blocked&&$remaining>0&&$user['role']==='customer'): ?><a class="button" href="balance-new.php?request_id=<?= $id ?>">แนบสลิปยอดคงเหลือ ↗</a><?php endif; ?><?php foreach($balances as $b): ?><p><a href="balance.php?id=<?= (int)$b['id'] ?>"><?= balance_number((int)$b['id']) ?> · <?= money($b['amount']) ?> · <?= e(balance_label($b['status'])) ?> ↗</a></p><?php endforeach; ?></section>
<?php endif; ?>
