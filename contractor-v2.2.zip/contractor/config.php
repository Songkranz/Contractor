<?php
declare(strict_types=1);

// XAMPP defaults. Change these values if your database uses another account.
return [
    'db_host' => getenv('CONTRACTOR_DB_HOST') ?: '127.0.0.1',
    'db_name' => getenv('CONTRACTOR_DB_NAME') ?: 'contractor_db',
    'db_user' => getenv('CONTRACTOR_DB_USER') ?: 'root',
    'db_pass' => getenv('CONTRACTOR_DB_PASS') ?: '',
    // Apache blocks direct access to storage via storage/.htaccess.
    'upload_dir' => getenv('CONTRACTOR_UPLOAD_DIR') ?: __DIR__ . '/storage/request-images',
    'payment_upload_dir' => getenv('CONTRACTOR_PAYMENT_UPLOAD_DIR') ?: __DIR__ . '/storage/payment-slips',
];
