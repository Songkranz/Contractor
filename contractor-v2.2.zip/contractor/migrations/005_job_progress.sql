ALTER TABLE service_requests MODIFY status ENUM('pending','awaiting_deposit','ready','rejected','payment_review','scheduled','traveling','in_progress','completed') NOT NULL DEFAULT 'pending';
CREATE TABLE IF NOT EXISTS job_progress (
    request_id INT UNSIGNED PRIMARY KEY,
    appointment_at DATETIME NULL,
    arrival_at DATETIME NULL,
    completed_at DATETIME NULL,
    revision INT UNSIGNED NOT NULL DEFAULT 1,
    FOREIGN KEY (request_id) REFERENCES service_requests(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
