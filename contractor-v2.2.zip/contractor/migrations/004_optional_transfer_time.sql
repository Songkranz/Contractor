-- Existing recorded transfer times are preserved. New submissions use the slip as evidence.
ALTER TABLE deposit_payments MODIFY transferred_at DATETIME NULL DEFAULT NULL;
