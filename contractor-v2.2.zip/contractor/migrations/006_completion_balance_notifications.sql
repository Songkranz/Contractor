CREATE TABLE IF NOT EXISTS balance_payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    submitted_by INT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transferred_at DATETIME NULL,
    customer_note VARCHAR(1000) NULL,
    storage_name VARCHAR(80) NOT NULL UNIQUE,
    mime_type VARCHAR(30) NOT NULL,
    byte_size INT UNSIGNED NOT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    review_note VARCHAR(2000) NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    submission_key CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_balance_request (request_id, id),
    INDEX idx_balance_queue (status, created_at),
    FOREIGN KEY (request_id) REFERENCES service_requests(id),
    FOREIGN KEY (submitted_by) REFERENCES users(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS completion_images LIKE request_images;
CREATE TABLE IF NOT EXISTS notification_reads (user_id INT UNSIGNED NOT NULL, history_id INT UNSIGNED NOT NULL, PRIMARY KEY(user_id, history_id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(history_id) REFERENCES request_status_history(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
