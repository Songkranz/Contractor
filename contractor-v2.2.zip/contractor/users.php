<?php
require __DIR__ . '/includes/bootstrap.php'; $user = require_admin(); $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $target = filter_var($_POST['user_id'] ?? '', FILTER_VALIDATE_INT); $role = post_string('role');
    if (!$target || !in_array($role, ['customer', 'staff', 'admin'], true)) { $error = 'ข้อมูลสิทธิ์ไม่ถูกต้อง'; }
    elseif ($target === (int) $user['id']) { $error = 'ไม่สามารถเปลี่ยนสิทธิ์ของบัญชีตนเองได้'; }
    else {
        $stmt = db()->prepare('UPDATE users SET role = ? WHERE id = ?'); $stmt->execute([$role, $target]);
        flash('บันทึกสิทธิ์เรียบร้อยแล้ว'); redirect('users.php');
    }
}
$search = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 100) : '';
$stmt = db()->prepare('SELECT id, username, full_name, email, role FROM users WHERE full_name LIKE ? OR username LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 100');
$term = '%' . $search . '%'; $stmt->execute([$term, $term, $term]); $members = $stmt->fetchAll();
$title = 'จัดการผู้ใช้งาน'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="dashboard.php">← กลับแดชบอร์ด</a><div class="workspace-heading"><div><p class="eyebrow">ACCESS MANAGEMENT</p><h1>จัดการผู้ใช้งาน</h1><p class="subtle">ให้พนักงานสมัครบัญชีก่อน แล้วเปลี่ยนสิทธิ์จากหน้านี้</p></div><span class="badge">ผู้ดูแลระบบ</span></div>
<?php if ($error): ?><div class="alert error" role="alert"><?= e($error) ?></div><?php endif; ?>
<section class="panel"><form method="get" class="search-form"><label for="q" class="sr-only">ค้นหาชื่อ ชื่อผู้ใช้ หรืออีเมล</label><input id="q" name="q" value="<?= e($search) ?>" placeholder="ค้นหาชื่อ ชื่อผู้ใช้ หรืออีเมล" maxlength="100"><button class="button" type="submit">ค้นหา</button></form><p class="subtle">แสดงล่าสุดสูงสุด 100 บัญชีที่ตรงกับการค้นหา</p>
<div class="table-scroll"><table><thead><tr><th>ชื่อ-นามสกุล</th><th>ชื่อผู้ใช้ / อีเมล</th><th>สิทธิ์การใช้งาน</th></tr></thead><tbody>
<?php foreach ($members as $member): ?><tr><td><?= e($member['full_name']) ?></td><td><?= e($member['username']) ?><small><?= e($member['email']) ?></small></td><td>
<?php if ((int) $member['id'] === (int) $user['id']): ?><span class="badge">ผู้ดูแลระบบ · คุณ</span><?php else: ?><form method="post" class="role-form"><?= csrf() ?><input type="hidden" name="user_id" value="<?= (int) $member['id'] ?>"><select name="role" aria-label="สิทธิ์ของ <?= e($member['username']) ?>"><?php foreach (['customer', 'staff', 'admin'] as $role): ?><option value="<?= $role ?>" <?= $role === $member['role'] ? 'selected' : '' ?>><?= e(role_label($role)) ?></option><?php endforeach; ?></select><button class="button button-small" type="submit">บันทึก</button></form><?php endif; ?>
</td></tr><?php endforeach; ?>
<?php if (!$members): ?><tr><td colspan="3">ไม่พบบัญชีที่ตรงกับการค้นหา</td></tr><?php endif; ?>
</tbody></table></div></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
