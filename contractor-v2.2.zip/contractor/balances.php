<?php
require __DIR__ . '/includes/balances.php'; $user = require_user(); $reviewer = is_reviewer($user);
$status = is_string($_GET['status'] ?? null) && isset(balance_statuses()[$_GET['status']]) ? $_GET['status'] : '';
$q = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 100) : '';
$where = []; $params = [];
if (!$reviewer) { $where[] = 'r.customer_id = ?'; $params[] = $user['id']; }
if ($status !== '') { $where[] = 'p.status = ?'; $params[] = $status; }
if ($q !== '') {
    $where[] = '(r.title LIKE ? OR p.id = ? OR r.id = ?)'; $params[] = '%' . $q . '%';
    $params[] = preg_match('/\ABAL-0*([0-9]{1,10})\z/i', $q, $match) ? (int) $match[1] : 0;
    $params[] = preg_match('/\ARQ-0*([0-9]{1,10})\z/i', $q, $match) ? (int) $match[1] : 0;
}
$condition = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$from = ' FROM balance_payments p JOIN service_requests r ON r.id = p.request_id';
$stmt = db()->prepare('SELECT COUNT(*)' . $from . $condition); $stmt->execute($params); $total = (int) $stmt->fetchColumn();
$lastPage = max(1, (int) ceil($total / 10)); $page = min($lastPage, max(1, (int) (filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT) ?: 1)));
$stmt = db()->prepare('SELECT p.id, p.request_id, p.amount, p.status, p.created_at, r.title' . $from . $condition . ' ORDER BY p.created_at DESC, p.id DESC LIMIT 10 OFFSET ' . (($page - 1) * 10)); $stmt->execute($params); $payments = $stmt->fetchAll();
$title = $reviewer ? 'ตรวจสลิปยอดคงเหลือ' : 'หลักฐานยอดคงเหลือของฉัน'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="dashboard.php">← แดชบอร์ด</a><div class="workspace-heading"><div><p class="eyebrow">BALANCE PAYMENTS</p><h1><?= e($title) ?></h1><p class="subtle"><?= $reviewer ? 'เปิดภาพสลิป ตรวจข้อมูล แล้วแจ้งผลให้ลูกค้าทราบ' : 'ติดตามผลตรวจหลักฐานและดูประวัติการส่งสลิป' ?></p></div><span class="badge"><?= e(role_label($user['role'])) ?></span></div>
<section class="panel"><form method="get" class="payment-filters"><label>ค้นหาหลักฐาน<input name="q" value="<?= e($q) ?>" maxlength="100" placeholder="หัวข้องาน, BAL-00001 หรือ RQ-00001"></label><label>สถานะ<select name="status"><option value="">ทุกสถานะ</option><?php foreach (balance_statuses() as $key => $label): ?><option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><button class="button" type="submit">ค้นหา</button><a class="text-link" href="balances.php">ล้างตัวกรอง</a></form><div class="results-heading"><span>พบ <?= $total ?> รายการ</span><span>ล่าสุดก่อน</span></div>
<?php if (!$payments): ?><div class="empty-state"><span class="empty-symbol" aria-hidden="true">▤</span><h2>ยังไม่มีหลักฐานในรายการนี้</h2><p class="subtle"><?= $q || $status ? 'ลองเปลี่ยนคำค้นหาหรือตัวกรอง' : ($reviewer ? 'เมื่อลูกค้าส่งสลิป หลักฐานจะแสดงที่นี่' : 'แนบสลิปได้จากคำขอที่อยู่ในสถานะรอชำระยอดคงเหลือ') ?></p><a class="button button-outline" href="requests.php">ดูคำขอรับเหมา ↗</a></div><?php else: ?><div class="request-list"><?php foreach ($payments as $payment): ?><article class="request-card"><div class="request-card-main"><div class="request-meta"><span class="request-code"><?= balance_number((int) $payment['id']) ?></span><span><?= request_number((int) $payment['request_id']) ?></span></div><h2><a href="balance.php?id=<?= (int) $payment['id'] ?>"><?= e($payment['title']) ?></a></h2><p class="subtle"><?= money($payment['amount']) ?> · ส่งเมื่อ <?= e(short_date($payment['created_at'])) ?></p></div><div class="request-card-actions"><span class="payment-badge payment-<?= e($payment['status']) ?>"><?= e(balance_label($payment['status'])) ?></span><a class="text-link" href="balance.php?id=<?= (int) $payment['id'] ?>"><?= $reviewer && $payment['status'] === 'pending' ? 'ตรวจสลิป' : 'ดูหลักฐาน' ?> ↗</a></div></article><?php endforeach; ?></div>
<?php if ($lastPage > 1): ?><nav class="pagination" aria-label="หน้ารายการหลักฐาน"><?php if ($page > 1): ?><a class="button button-small button-outline" href="balances.php?<?= e(http_build_query(['q' => $q, 'status' => $status, 'page' => $page - 1])) ?>">← ก่อนหน้า</a><?php endif; ?><span>หน้า <?= $page ?> / <?= $lastPage ?></span><?php if ($page < $lastPage): ?><a class="button button-small button-outline" href="balances.php?<?= e(http_build_query(['q' => $q, 'status' => $status, 'page' => $page + 1])) ?>">ถัดไป →</a><?php endif; ?></nav><?php endif; ?><?php endif; ?></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
