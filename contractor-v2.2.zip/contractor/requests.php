<?php
require __DIR__ . '/includes/requests.php'; $user = require_user(); $reviewer = is_reviewer($user);
$q = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 100) : '';
$status = is_string($_GET['status'] ?? null) && isset(request_statuses()[$_GET['status']]) ? $_GET['status'] : '';
$typeId = filter_var($_GET['type'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$types = db()->query('SELECT id, name FROM job_types ORDER BY id')->fetchAll();
$where = []; $params = [];
if (!$reviewer) { $where[] = 'r.customer_id = ?'; $params[] = $user['id']; }
if ($status !== '') { $where[] = 'r.status = ?'; $params[] = $status; }
if ($typeId) { $where[] = 'r.job_type_id = ?'; $params[] = $typeId; }
if ($q !== '') {
    $where[] = '(r.title LIKE ? OR r.contact_name LIKE ? OR r.id = ?)';
    $params[] = '%' . $q . '%'; $params[] = '%' . $q . '%';
    $params[] = preg_match('/\A(?:RQ-)?0*([0-9]{1,10})\z/i', $q, $match) ? (int) $match[1] : 0;
}
$condition = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$stmt = db()->prepare('SELECT COUNT(*) FROM service_requests r' . $condition); $stmt->execute($params); $total = (int) $stmt->fetchColumn();
$lastPage = max(1, (int) ceil($total / 10));
$page = min($lastPage, max(1, (int) (filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT) ?: 1)));
$offset = ($page - 1) * 10;
$stmt = db()->prepare('SELECT r.*, t.name AS job_type FROM service_requests r JOIN job_types t ON t.id = r.job_type_id' . $condition . ' ORDER BY r.created_at DESC, r.id DESC LIMIT 10 OFFSET ' . $offset);
$stmt->execute($params); $requests = $stmt->fetchAll();
$title = $reviewer ? 'ตรวจคำขอรับเหมา' : 'คำขอของฉัน'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="dashboard.php">← แดชบอร์ด</a><div class="workspace-heading"><div><p class="eyebrow"><?= $reviewer ? 'SERVICE REQUESTS' : 'MY PROJECTS' ?></p><h1><?= e($title) ?></h1><p class="subtle"><?= $reviewer ? 'ตรวจรายละเอียดงานและแจ้งผลพิจารณาให้ลูกค้าทราบ' : 'รวมรายละเอียดและผลพิจารณางานรับเหมาของคุณ' ?></p></div><?php if (!$reviewer): ?><a class="button" href="request-new.php">+ ส่งคำขอใหม่</a><?php else: ?><span class="badge"><?= e(role_label($user['role'])) ?></span><?php endif; ?></div>
<section class="panel"><form method="get" class="request-filters"><label>ค้นหาคำขอ<input name="q" value="<?= e($q) ?>" maxlength="100" placeholder="หัวข้อ ผู้ติดต่อ หรือ RQ-00001"></label><label>สถานะ<select name="status"><option value="">ทุกสถานะ</option><?php foreach (request_statuses() as $key => $label): ?><option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select></label><label>ประเภทงาน<select name="type"><option value="">ทุกประเภท</option><?php foreach ($types as $type): ?><option value="<?= (int) $type['id'] ?>" <?= $typeId === (int) $type['id'] ? 'selected' : '' ?>><?= e($type['name']) ?></option><?php endforeach; ?></select></label><button class="button" type="submit">ค้นหา</button><a class="text-link" href="requests.php">ล้างตัวกรอง</a></form>
<div class="results-heading"><span>พบ <?= number_format($total) ?> คำขอ</span><span>ล่าสุดก่อน</span></div>
<?php if (!$requests): ?><div class="empty-state"><span class="empty-symbol" aria-hidden="true">⌂</span><h2>ยังไม่มีคำขอในรายการนี้</h2><p class="subtle"><?= ($q !== '' || $status !== '' || $typeId) ? 'ลองเปลี่ยนตัวกรองหรือคำค้นหา' : ($reviewer ? 'เมื่อมีลูกค้าส่งคำขอ รายละเอียดจะแสดงที่นี่' : 'เริ่มจากบอกประเภทงานและรายละเอียดพื้นที่ของคุณ') ?></p><?php if (!$reviewer): ?><a class="button" href="request-new.php">เริ่มคำขอแรก ↗</a><?php endif; ?></div>
<?php else: ?><div class="request-list"><?php foreach ($requests as $request): ?><article class="request-card"><div class="request-card-main"><div class="request-meta"><span class="request-code"><?= request_number((int) $request['id']) ?></span><span><?= e($request['job_type']) ?></span></div><h2><a href="request.php?id=<?= (int) $request['id'] ?>"><?= e($request['title']) ?></a></h2><p class="subtle"><?= $reviewer ? 'ผู้ติดต่อ ' . e($request['contact_name']) . ' · ' : '' ?>ส่งเมื่อ <?= e(short_date($request['created_at'])) ?></p></div><div class="request-card-actions"><span class="status-badge status-<?= e($request['status']) ?>"><?= e(status_label($request['status'])) ?></span><a class="text-link" href="request.php?id=<?= (int) $request['id'] ?>"><?= $reviewer && $request['status'] === 'pending' ? 'ตรวจคำขอ' : 'ดูรายละเอียด' ?> ↗</a></div></article><?php endforeach; ?></div>
<?php if ($lastPage > 1): ?><nav class="pagination" aria-label="หน้ารายการคำขอ"><?php if ($page > 1): ?><a class="button button-small button-outline" href="requests.php?<?= e(http_build_query(['q' => $q, 'status' => $status, 'type' => $typeId, 'page' => $page - 1])) ?>">← ก่อนหน้า</a><?php endif; ?><span>หน้า <?= $page ?> / <?= $lastPage ?></span><?php if ($page < $lastPage): ?><a class="button button-small button-outline" href="requests.php?<?= e(http_build_query(['q' => $q, 'status' => $status, 'type' => $typeId, 'page' => $page + 1])) ?>">ถัดไป →</a><?php endif; ?></nav><?php endif; ?>
<?php endif; ?></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
