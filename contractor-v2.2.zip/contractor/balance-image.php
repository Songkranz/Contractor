<?php
require __DIR__ . '/includes/balances.php'; $user = require_user();
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$payment = balance_for_user($id, $user);
if (!preg_match('/\A[a-f0-9]{48}\.(jpg|png|webp)\z/', $payment['storage_name']) || !in_array($payment['mime_type'], ['image/jpeg', 'image/png', 'image/webp'], true)) { http_response_code(404); exit('ไม่พบภาพสลิป'); }
$path = balance_directory() . '/' . $payment['storage_name'];
if (!is_file($path)) { http_response_code(404); exit('ไม่พบภาพสลิป'); }
session_write_close(); header('Content-Type: ' . $payment['mime_type']); header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="deposit-slip.' . pathinfo($path, PATHINFO_EXTENSION) . '"');
readfile($path);
