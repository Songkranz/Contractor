'use strict';
document.querySelectorAll('[data-show-password]').forEach((checkbox) => {
  const fields = checkbox.closest('form').querySelectorAll('input[type="password"]');
  checkbox.addEventListener('change', () => {
    fields.forEach((field) => { field.type = checkbox.checked ? 'text' : 'password'; });
  });
});

const imageInput = document.querySelector('[data-image-input]');
if (imageInput) {
  imageInput.addEventListener('change', () => {
    const files = Array.from(imageInput.files);
    const maxFiles = Number(imageInput.dataset.maxFiles || 3);
    const invalid = files.length > maxFiles || files.some((file) => file.size > 2 * 1024 * 1024 || !['image/jpeg', 'image/png', 'image/webp'].includes(file.type));
    const message = invalid ? `เลือกรูป JPG, PNG หรือ WebP ไม่เกิน ${maxFiles} รูป รูปละไม่เกิน 2 MB` : '';
    imageInput.setCustomValidity(message);
    document.querySelector('[data-file-feedback]').textContent = message || (files.length ? `เลือกแล้ว ${files.length} รูป: ${files.map((file) => file.name).join(', ')}` : '');
  });
}

const reviewForm = document.querySelector('[data-review-form]');
if (reviewForm) {
  const decision = reviewForm.querySelector('[data-decision]');
  const note = reviewForm.querySelector('[data-review-note]');
  const total = reviewForm.querySelector('[name="quoted_total"]');
  const deposit = reviewForm.querySelector('[name="deposit_amount"]');
  const updateReview = () => {
    const approved = decision.value === 'approve';
    reviewForm.querySelector('[data-quote-fields]').hidden = !approved;
    reviewForm.querySelectorAll('[data-approval-required]').forEach((field) => {
      field.required = approved;
      field.disabled = !approved;
    });
    note.required = !approved;
    note.minLength = approved ? 0 : 5;
    reviewForm.querySelector('[data-note-label]').textContent = approved ? 'หมายเหตุถึงลูกค้า (ไม่บังคับ)' : 'เหตุผลที่ไม่อนุมัติ (จำเป็น)';
    deposit.setCustomValidity(approved && total.value && deposit.value && Number(deposit.value) > Number(total.value) ? 'ค่ามัดจำต้องไม่เกินค่าใช้จ่ายรวม' : '');
  };
  decision.addEventListener('change', updateReview);
  total.addEventListener('input', updateReview);
  deposit.addEventListener('input', updateReview);
  updateReview();
}

const paymentReview = document.querySelector('[data-payment-review]');
if (paymentReview) {
  const decision = paymentReview.querySelector('[data-payment-decision]');
  const note = paymentReview.querySelector('[data-payment-note]');
  const confirmation = paymentReview.querySelector('[data-payment-confirm]');
  const updatePaymentReview = () => {
    const approved = decision.value === 'approve';
    confirmation.hidden = !approved;
    confirmation.querySelector('input').required = approved;
    confirmation.querySelector('input').disabled = !approved;
    note.required = !approved;
    note.minLength = approved ? 0 : 5;
    paymentReview.querySelector('[data-payment-note-label]').textContent = approved ? 'หมายเหตุถึงลูกค้า (ไม่บังคับ)' : 'เหตุผลที่หลักฐานไม่ผ่าน (จำเป็น)';
  };
  decision.addEventListener('change', updatePaymentReview);
  updatePaymentReview();
}

const serviceScene = document.querySelector('[data-service-scene]');
if (serviceScene) {
  const scenes = [
    ['ก่อสร้าง', 'วางรากฐานให้พื้นที่ใหม่', '01 / BUILD WITH CARE'],
    ['ต่อเติม', 'เพิ่มพื้นที่ให้พอดีกับชีวิต', '02 / ROOM TO GROW'],
    ['ซ่อมแซม', 'ดูแลบ้านให้พร้อมใช้งาน', '03 / REPAIR WITH CARE'],
    ['ปลูกต้นไม้', 'เติมพื้นที่สีเขียวให้บ้าน', '04 / GROW SOMETHING GOOD']
  ];
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  let current = 0;
  let paused = reduced.matches;
  let timer;
  const pauseButton = serviceScene.querySelector('[data-scene-pause]');
  const show = (index) => {
    serviceScene.classList.toggle('cycle-start', index === 0);
    current = index;
    serviceScene.dataset.scene = String(index);
    serviceScene.querySelector('[data-scene-title]').textContent = scenes[index][0];
    serviceScene.querySelector('[data-scene-subtitle]').textContent = scenes[index][1];
    serviceScene.querySelector('[data-scene-number]').textContent = scenes[index][2];
    serviceScene.querySelectorAll('[data-scene-select]').forEach((button, i) => button.setAttribute('aria-pressed', String(i === index)));
    document.querySelectorAll('[data-service-card]').forEach((card, i) => card.classList.toggle('is-current', i === index));
  };
  const schedule = () => {
    clearInterval(timer);
    serviceScene.classList.toggle('is-paused', paused || document.hidden);
    pauseButton.textContent = paused ? 'เล่น' : 'หยุด';
    pauseButton.setAttribute('aria-label', paused ? 'เล่นภาพสลับอัตโนมัติ' : 'หยุดภาพสลับอัตโนมัติ');
    if (!paused && !document.hidden) timer = setInterval(() => show((current + 1) % scenes.length), 5000);
  };
  serviceScene.querySelectorAll('[data-scene-select]').forEach((button) => button.addEventListener('click', () => { show(Number(button.dataset.sceneSelect)); schedule(); }));
  pauseButton.addEventListener('click', () => { paused = !paused; schedule(); });
  document.addEventListener('visibilitychange', schedule);
  reduced.addEventListener('change', () => { paused = reduced.matches; schedule(); });
  show(0); schedule();
}
