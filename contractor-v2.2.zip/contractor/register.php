<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) { redirect('dashboard.php'); }
$errors = []; $data = ['username' => '', 'full_name' => '', 'email' => '', 'phone' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($data as $key => $_) { $data[$key] = post_string($key); }
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    if (!preg_match('/\A[a-zA-Z0-9_]{4,30}\z/', $data['username'])) { $errors[] = 'ชื่อผู้ใช้ต้องเป็นภาษาอังกฤษ ตัวเลข หรือ _ จำนวน 4–30 ตัว'; }
    if (mb_strlen($data['full_name']) < 2 || mb_strlen($data['full_name']) > 100) { $errors[] = 'กรุณาระบุชื่อ-นามสกุล 2–100 ตัวอักษร'; }
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) || strlen($data['email']) > 190) { $errors[] = 'กรุณาระบุอีเมลให้ถูกต้อง'; }
    if (!preg_match('/\A[0-9]{9,10}\z/', $data['phone'])) { $errors[] = 'กรุณาระบุเบอร์โทรศัพท์เป็นตัวเลข 9–10 หลัก'; }
    if (strlen($password) < 8 || strlen($password) > 72) { $errors[] = 'รหัสผ่านต้องมีความยาว 8–72 ไบต์ (ภาษาอังกฤษอย่างน้อย 8 ตัว)'; }
    if ($password !== ($_POST['password_confirm'] ?? null)) { $errors[] = 'รหัสผ่านทั้งสองช่องไม่ตรงกัน'; }
    if (!$errors) {
        try {
            $stmt = db()->prepare("INSERT INTO users (username, full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?, 'customer')");
            $stmt->execute([$data['username'], $data['full_name'], $data['email'], $data['phone'], password_hash($password, PASSWORD_DEFAULT)]);
            flash('สมัครสมาชิกเรียบร้อยแล้ว กรุณาเข้าสู่ระบบ'); redirect('login.php');
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') { $errors[] = 'ชื่อผู้ใช้หรืออีเมลนี้มีผู้ใช้แล้ว'; }
            else { error_log($exception->getMessage()); $errors[] = 'บันทึกข้อมูลไม่สำเร็จ กรุณาลองใหม่'; }
        }
    }
}
$title = 'สมัครสมาชิก'; require __DIR__ . '/includes/header.php';
?>
<main class="auth-layout container"><aside class="auth-intro"><p class="eyebrow">LET’S GET STARTED</p><h1>เริ่มต้นพื้นที่ใหม่<br>ด้วยบัญชี<span>ของคุณ</span></h1><p>สร้างบัญชีลูกค้าสำหรับติดต่อทีมงาน<br>และจัดการข้อมูลส่วนตัวของคุณ</p><div class="auth-decoration" aria-hidden="true">S<span>.</span></div><p class="subtle">ซาเล็ง กรุ๊ป · งานรับเหมาอิสระ</p></aside>
<section class="form-card"><p class="eyebrow">CREATE AN ACCOUNT</p><h2>สมัครสมาชิก</h2><p class="subtle">มีบัญชีแล้ว? <a href="login.php">เข้าสู่ระบบ</a></p>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" class="stack-form"><?= csrf() ?>
<label>ชื่อ-นามสกุล<input name="full_name" autocomplete="name" required maxlength="100" value="<?= e($data['full_name']) ?>" placeholder="ชื่อและนามสกุลของคุณ"></label>
<label>ชื่อผู้ใช้<input name="username" autocomplete="username" required pattern="[a-zA-Z0-9_]{4,30}" maxlength="30" value="<?= e($data['username']) ?>" placeholder="เช่น somchai_01"><small>ภาษาอังกฤษ ตัวเลข หรือ _ จำนวน 4–30 ตัว</small></label>
<div class="form-row"><label>อีเมล<input type="email" name="email" autocomplete="email" required maxlength="190" value="<?= e($data['email']) ?>" placeholder="you@example.com"></label><label>เบอร์โทรศัพท์<input type="tel" name="phone" autocomplete="tel" required pattern="[0-9]{9,10}" maxlength="10" value="<?= e($data['phone']) ?>" placeholder="0812345678"></label></div>
<label>รหัสผ่าน<input type="password" name="password" autocomplete="new-password" required minlength="8" maxlength="72" placeholder="อย่างน้อย 8 ตัวอักษร"></label>
<label>ยืนยันรหัสผ่าน<input type="password" name="password_confirm" autocomplete="new-password" required minlength="8" maxlength="72" placeholder="กรอกรหัสผ่านอีกครั้ง"></label>
<label class="checkbox-label"><input type="checkbox" data-show-password> แสดงรหัสผ่าน</label>
<button class="button full-width" type="submit">สร้างบัญชีลูกค้า <span aria-hidden="true">↗</span></button>
</form></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
