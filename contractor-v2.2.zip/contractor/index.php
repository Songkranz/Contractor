<?php require __DIR__ . '/includes/bootstrap.php'; $title = 'บ้านที่ดี เริ่มจากทีมที่เข้าใจ'; require __DIR__ . '/includes/header.php'; ?>
<main>
    <section class="hero container">
        <div class="hero-copy">
            <p class="eyebrow"><span class="orange-dot"></span> งานรับเหมาอิสระ · บุรีรัมย์</p>
            <h1>ทุกพื้นที่มีเรื่องราว<br>ให้เราช่วย<span>สร้างต่อ</span></h1>
            <p class="hero-description">ก่อสร้าง ต่อเติม ซ่อมแซม และปลูกต้นไม้<br>เริ่มต้นด้วยทีมงานที่เข้าใจความต้องการของคุณ</p>
            <div class="hero-actions"><a class="button" href="<?= $navUser ? 'dashboard.php' : 'register.php' ?>"><?= $navUser ? 'ไปที่แดชบอร์ด' : 'เริ่มต้นสมัครสมาชิก' ?> <span aria-hidden="true">↗</span></a><a class="text-link" href="#services">ดูประเภทงาน <span aria-hidden="true">↓</span></a></div>
            <div class="hero-note"><span class="note-line"></span><p>พื้นที่สำหรับลูกค้าและทีมงาน<br><strong>เชื่อมต่อข้อมูลไว้ในที่เดียว</strong></p></div>
        </div>
        <div class="architecture service-scene" data-service-scene data-scene="0" role="region" aria-label="ภาพบริการทั้ง 4 ประเภท">
<div class="scene-art" aria-hidden="true">
            <div class="art-grid"></div><div class="art-sun"></div><div class="house-front"></div><div class="house-roof"></div><div class="house-window"></div><div class="house-door"></div><div class="house-step step-one"></div><div class="house-step step-two"></div><div class="art-ground"></div>
            <div class="scene-extension"></div><div class="scene-damage"><i></i><i></i><i></i></div><div class="scene-repair">⚒</div><div class="extra-repair repair-1"><span class="repair-crack">⌁</span><span class="repair-tool">⚒</span><span class="repair-dust"><i></i><i></i><i></i><i></i></span></div><div class="extra-repair repair-2"><span class="repair-crack">⌁</span><span class="repair-tool">⚒</span><span class="repair-dust"><i></i><i></i><i></i><i></i></span></div><div class="extra-repair repair-3"><span class="repair-crack">⌁</span><span class="repair-tool">⚒</span><span class="repair-dust"><i></i><i></i><i></i><i></i></span></div><div class="scene-tree"><div class="tree-trunk"></div><div class="tree-leaves"></div><div class="tree-leaves second"></div></div></div><span class="art-caption">A SPACE TO BEGIN.</span><span class="art-number" data-scene-number>01 / BUILD WITH CARE</span>
            <div class="art-tag"><span data-scene-subtitle>วางรากฐานให้พื้นที่ใหม่</span><strong data-scene-title>ก่อสร้าง</strong></div><div class="scene-controls" aria-label="เลือกภาพบริการ"><button type="button" data-scene-select="0" aria-label="ก่อสร้าง" aria-pressed="true">01</button><button type="button" data-scene-select="1" aria-label="ต่อเติม" aria-pressed="false">02</button><button type="button" data-scene-select="2" aria-label="ซ่อมแซม" aria-pressed="false">03</button><button type="button" data-scene-select="3" aria-label="ปลูกต้นไม้" aria-pressed="false">04</button><button type="button" data-scene-pause aria-label="หยุดภาพสลับอัตโนมัติ">หยุด</button></div>
        </div>
    </section>
    <section id="services" class="services container">
        <div class="section-heading"><div><p class="eyebrow">OUR SERVICES</p><h2>งานของเรา เริ่มที่ความต้องการของคุณ</h2></div><p>เลือกประเภทงานที่เหมาะกับพื้นที่ของคุณ</p></div>
        <div class="service-grid">
            <?php foreach ([['01', 'ก่อสร้าง', 'วางรากฐานให้พื้นที่ใหม่ของคุณ', '⌂'], ['02', 'ต่อเติม', 'เพิ่มพื้นที่ให้พอดีกับการใช้งาน', '＋'], ['03', 'ซ่อมแซม', 'ดูแลส่วนที่เสียหายให้กลับมาใช้งาน', '⌁'], ['04', 'ปลูกต้นไม้', 'เติมพื้นที่สีเขียวให้บ้านร่มรื่น', '♧']] as $service): ?>
            <article class="service-card" data-service-card="<?= (int)$service[0]-1 ?>"><div class="service-top"><span><?= $service[0] ?></span><span class="service-icon" aria-hidden="true"><?= $service[3] ?></span></div><h3><?= $service[1] ?></h3><p><?= $service[2] ?></p></article>
            <?php endforeach; ?>
        </div>
    </section>
    <section class="intro-strip container"><div><p class="eyebrow">YOUR PROJECT, CONNECTED</p><h2>เริ่มต้นบัญชีของคุณวันนี้</h2><p>สมัครสมาชิกเพื่อจัดเก็บข้อมูลติดต่อสำหรับการรับบริการ</p></div><a class="button button-light" href="<?= $navUser ? 'profile.php' : 'register.php' ?>"><?= $navUser ? 'จัดการข้อมูลส่วนตัว' : 'สร้างบัญชีลูกค้า' ?> ↗</a></section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
