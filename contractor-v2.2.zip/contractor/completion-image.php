<?php
require __DIR__ . '/includes/requests.php'; $user = require_user();
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$sql = 'SELECT i.* FROM completion_images i JOIN service_requests r ON r.id = i.request_id WHERE i.id = ?'; $params = [$id];
if (!is_reviewer($user)) { $sql .= ' AND r.customer_id = ?'; $params[] = $user['id']; }
$stmt = db()->prepare($sql); $stmt->execute($params); $image = $stmt->fetch();
if (!$image || !preg_match('/\A[a-f0-9]{48}\.(jpg|png|webp)\z/', $image['storage_name']) || !in_array($image['mime_type'], ['image/jpeg', 'image/png', 'image/webp'], true)) { http_response_code(404); exit('ไม่พบรูปภาพ'); }
$path = upload_directory() . '/' . $image['storage_name'];
if (!is_file($path)) { http_response_code(404); exit('ไม่พบรูปภาพ'); }
session_write_close();
header('Content-Type: ' . $image['mime_type']);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="request-image.' . pathinfo($path, PATHINFO_EXTENSION) . '"');
readfile($path);
