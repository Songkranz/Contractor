<?php
require __DIR__.'/includes/requests.php';require_once __DIR__.'/includes/notifications.php';$user=require_user();
[$scope,$params]=notification_scope($user);
if($_SERVER['REQUEST_METHOD']==='POST') {
 verify_csrf();$id=filter_var($_POST['history_id']??'',FILTER_VALIDATE_INT)?:0;
 $stmt=db()->prepare('INSERT IGNORE INTO notification_reads(user_id,history_id) SELECT ?,h.id FROM request_status_history h JOIN service_requests r ON r.id=h.request_id WHERE h.id=? AND '.$scope);
 $stmt->execute(array_merge([$user['id'],$id],$params));redirect('notifications.php');
}
$stmt=db()->prepare('SELECT h.*,r.title,n.history_id AS is_read FROM request_status_history h JOIN service_requests r ON r.id=h.request_id LEFT JOIN notification_reads n ON n.history_id=h.id AND n.user_id=? WHERE '.$scope.' ORDER BY (n.history_id IS NULL) DESC,h.id DESC LIMIT 100');
$stmt->execute(array_merge([$user['id']],$params));$items=$stmt->fetchAll();$title='การแจ้งเตือน';require __DIR__.'/includes/header.php';
?>
<main class="container workspace"><h1>การแจ้งเตือน</h1><p class="subtle">อัปเดตเมื่อเปิดหรือรีเฟรชหน้า แสดงล่าสุดสูงสุด 100 รายการ โดยรายการที่ยังไม่อ่านอยู่ก่อน</p><?php if(!$items): ?><p>ยังไม่มีการแจ้งเตือน</p><?php endif; ?><?php foreach($items as $item): ?><section class="panel"><h2><a href="request.php?id=<?= (int)$item['request_id'] ?>"><?= e($item['title']) ?></a></h2><p><?= e(status_label($item['status'])) ?> · <?= e(short_date($item['created_at'])) ?></p><p class="preserve-lines"><?= e($item['note']) ?></p><?php if(!$item['is_read']): ?><form method="post"><?= csrf() ?><input type="hidden" name="history_id" value="<?= (int)$item['id'] ?>"><button class="button button-small">ทำเครื่องหมายว่าอ่านแล้ว</button></form><?php else: ?><span class="subtle">อ่านแล้ว</span><?php endif; ?></section><?php endforeach; ?></main>
<?php require __DIR__.'/includes/footer.php'; ?>
