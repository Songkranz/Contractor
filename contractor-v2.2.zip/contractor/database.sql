-- Select contractor_db in phpMyAdmin before importing this file.
-- No default users or passwords are installed.
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(10) NOT NULL,
    address TEXT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'staff', 'admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Version 1.1: service request workflow
-- Safe to import again. Does not modify existing users or delete data.
CREATE TABLE IF NOT EXISTS job_types (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO job_types (name) VALUES
('งานก่อสร้าง'), ('งานต่อเติม'), ('งานซ่อมแซม'), ('งานทาสี'), ('งานปูกระเบื้อง'), ('งานอื่น ๆ')
ON DUPLICATE KEY UPDATE name = VALUES(name);

CREATE TABLE IF NOT EXISTS service_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL,
    job_type_id INT UNSIGNED NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    location TEXT NOT NULL,
    contact_name VARCHAR(100) NOT NULL,
    contact_phone VARCHAR(10) NOT NULL,
    preferred_date DATE NULL,
    status ENUM('pending', 'awaiting_deposit', 'ready', 'rejected') NOT NULL DEFAULT 'pending',
    quoted_total DECIMAL(10,2) NULL,
    deposit_amount DECIMAL(10,2) NULL,
    cost_details TEXT NULL,
    review_note TEXT NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    submission_key CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_customer_created (customer_id, created_at),
    INDEX idx_status_created (status, created_at),
    FOREIGN KEY (customer_id) REFERENCES users(id),
    FOREIGN KEY (job_type_id) REFERENCES job_types(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS request_images (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    storage_name VARCHAR(80) NOT NULL UNIQUE,
    mime_type VARCHAR(30) NOT NULL,
    byte_size INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES service_requests(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS request_status_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    actor_id INT UNSIGNED NOT NULL,
    status VARCHAR(30) NOT NULL,
    note TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES service_requests(id),
    FOREIGN KEY (actor_id) REFERENCES users(id),
    INDEX idx_request_history (request_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Version 1.2: deposit evidence
-- Run after migration 002. Preserves existing users, requests and images.
-- New enum value is appended so the existing status values keep their order.
ALTER TABLE service_requests
    MODIFY status ENUM('pending', 'awaiting_deposit', 'ready', 'rejected', 'payment_review') NOT NULL DEFAULT 'pending';

CREATE TABLE IF NOT EXISTS deposit_payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    submitted_by INT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transferred_at DATETIME NOT NULL,
    customer_note VARCHAR(1000) NULL,
    storage_name VARCHAR(80) NOT NULL UNIQUE,
    mime_type VARCHAR(30) NOT NULL,
    byte_size INT UNSIGNED NOT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    review_note VARCHAR(2000) NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    submission_key CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_payment_request (request_id, id),
    INDEX idx_payment_queue (status, created_at),
    FOREIGN KEY (request_id) REFERENCES service_requests(id),
    FOREIGN KEY (submitted_by) REFERENCES users(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Simplified slip submission
-- Existing recorded transfer times are preserved. New submissions use the slip as evidence.
ALTER TABLE deposit_payments MODIFY transferred_at DATETIME NULL DEFAULT NULL;

ALTER TABLE service_requests MODIFY status ENUM('pending','awaiting_deposit','ready','rejected','payment_review','scheduled','traveling','in_progress','completed') NOT NULL DEFAULT 'pending';
CREATE TABLE IF NOT EXISTS job_progress (
    request_id INT UNSIGNED PRIMARY KEY,
    appointment_at DATETIME NULL,
    arrival_at DATETIME NULL,
    completed_at DATETIME NULL,
    revision INT UNSIGNED NOT NULL DEFAULT 1,
    FOREIGN KEY (request_id) REFERENCES service_requests(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS balance_payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    submitted_by INT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transferred_at DATETIME NULL,
    customer_note VARCHAR(1000) NULL,
    storage_name VARCHAR(80) NOT NULL UNIQUE,
    mime_type VARCHAR(30) NOT NULL,
    byte_size INT UNSIGNED NOT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    review_note VARCHAR(2000) NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    submission_key CHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_balance_request (request_id, id),
    INDEX idx_balance_queue (status, created_at),
    FOREIGN KEY (request_id) REFERENCES service_requests(id),
    FOREIGN KEY (submitted_by) REFERENCES users(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS completion_images LIKE request_images;
CREATE TABLE IF NOT EXISTS notification_reads (user_id INT UNSIGNED NOT NULL, history_id INT UNSIGNED NOT NULL, PRIMARY KEY(user_id, history_id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(history_id) REFERENCES request_status_history(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_addresses (
 user_id INT UNSIGNED PRIMARY KEY,
 house_number VARCHAR(50) NOT NULL DEFAULT '',
 village VARCHAR(50) NOT NULL DEFAULT '',
 road VARCHAR(100) NOT NULL DEFAULT '',
 subdistrict VARCHAR(100) NOT NULL DEFAULT '',
 district VARCHAR(100) NOT NULL DEFAULT '',
 province VARCHAR(100) NOT NULL DEFAULT '',
 postal_code VARCHAR(5) NOT NULL DEFAULT '',
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
