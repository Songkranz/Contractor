<?php
require __DIR__ . '/includes/balances.php'; $user = require_user();
if ($user['role'] !== 'customer') { http_response_code(403); exit('การแจ้งชำระยอดคงเหลือสำหรับลูกค้าเจ้าของคำขอเท่านั้น'); }
$requestId = filter_var($_GET['request_id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$request = request_for_user($requestId, $user);
$stmt = db()->prepare("SELECT (quoted_total - COALESCE((SELECT SUM(amount) FROM deposit_payments WHERE request_id=service_requests.id AND status='approved'),0)) AS deposit_amount FROM service_requests WHERE id=?"); $stmt->execute([$requestId]); $request['deposit_amount']=$stmt->fetchColumn();
$errors = []; $data = ['customer_note' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        $errors[] = 'ไฟล์มีขนาดใหญ่เกินกำหนด กรุณาเลือกภาพสลิปขนาดไม่เกิน 2 MB';
    } else {
        verify_csrf();
        foreach ($data as $key => $_) { $data[$key] = post_string($key); }
        $key = post_string('submission_key');
        if (preg_match('/\A[a-f0-9]{64}\z/', $key)) {
            $existing = db()->prepare('SELECT id FROM balance_payments WHERE submission_key = ? AND request_id = ? AND submitted_by = ?');
            $existing->execute([$key, $requestId, $user['id']]);
            if ($existingId = $existing->fetchColumn()) { redirect('balance.php?id=' . $existingId); }
        }
        if (!preg_match('/\A[a-f0-9]{64}\z/', $key) || !hash_equals($_SESSION['balance_keys'][$requestId] ?? '', $key)) { $errors[] = 'แบบฟอร์มหมดอายุ กรุณาเปิดหน้าแนบสลิปใหม่'; }
        // Use the required deposit from the database; actual transfer details are checked on the slip.
        $cents = money_cents($request['deposit_amount'] ?? '');
        if ($cents === null || $cents <= 0) { $errors[] = 'คำขอนี้ไม่มียอดคงเหลือที่ต้องชำระ'; }
        if (mb_strlen($data['customer_note']) > 1000) { $errors[] = 'หมายเหตุต้องไม่เกิน 1,000 ตัวอักษร'; }
        $images = validate_request_images($errors, 'slip', 1);
        if (!$images && !$errors) { $errors[] = 'กรุณาแนบภาพสลิป 1 รูป'; }
        if ($request['status'] !== 'completed') { $errors[] = 'คำขอนี้ยังไม่เปิดให้ส่งสลิป หรือมีหลักฐานที่รอตรวจสอบอยู่แล้ว'; }
        if (!$errors) {
            $savedPath = null;
            try {
                db()->beginTransaction();
                // All payment writes lock the parent request first, then the payment row.
                $stmt = db()->prepare("SELECT status, (quoted_total - COALESCE((SELECT SUM(amount) FROM deposit_payments WHERE request_id=service_requests.id AND status='approved'),0)) AS deposit_amount FROM service_requests WHERE id = ? FOR UPDATE"); $stmt->execute([$requestId]); $locked = $stmt->fetch();
                if (!$locked || $locked['status'] !== 'completed' || money_cents($locked['deposit_amount']) !== $cents) { throw new DomainException('สถานะหรือยอดคงเหลือมีการเปลี่ยนแปลง กรุณากลับไปเปิดคำขอใหม่'); }
                $stmt = db()->prepare("SELECT id FROM balance_payments WHERE request_id = ? AND status IN ('pending', 'approved') LIMIT 1"); $stmt->execute([$requestId]);
                if ($stmt->fetchColumn()) { throw new DomainException('คำขอนี้มีหลักฐานที่รอตรวจหรืออนุมัติแล้ว ไม่สามารถส่งซ้ำได้'); }
                if (!is_dir(balance_directory()) && !mkdir(balance_directory(), 0750, true) && !is_dir(balance_directory())) { throw new RuntimeException('Cannot create slip storage'); }
                $image = $images[0]; $destination = balance_directory() . '/' . $image['name'];
                if (!move_uploaded_file($image['tmp'], $destination)) { throw new RuntimeException('Cannot save slip'); }
                $savedPath = $destination;
                $stmt = db()->prepare('INSERT INTO balance_payments (request_id, submitted_by, amount, transferred_at, customer_note, storage_name, mime_type, byte_size, submission_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$requestId, $user['id'], decimal_money($cents), null, $data['customer_note'] ?: null, $image['name'], $image['mime'], $image['size'], $key]);
                $paymentId = (int) db()->lastInsertId();
                $stmt = db()->prepare("UPDATE service_requests SET status = 'completed' WHERE id = ?"); $stmt->execute([$requestId]);
                $stmt = db()->prepare("INSERT INTO request_status_history (request_id, actor_id, status, note) VALUES (?, ?, 'completed', ?)");
                $stmt->execute([$requestId, $user['id'], 'ลูกค้าส่งหลักฐาน ' . balance_number($paymentId) . ' สำหรับยอดคงเหลือ ' . money(decimal_money($cents)) . ' รอทีมงานตรวจสอบ']);
                db()->commit(); unset($_SESSION['balance_keys'][$requestId]);
                flash('ส่งสลิปเรียบร้อยแล้ว กรุณารอทีมงานตรวจสอบหลักฐาน'); redirect('balance.php?id=' . $paymentId);
            } catch (Throwable $exception) {
                if (db()->inTransaction()) { db()->rollBack(); }
                if ($savedPath && is_file($savedPath)) { unlink($savedPath); }
                if ($exception instanceof DomainException) { $errors[] = $exception->getMessage(); }
                else { error_log($exception->getMessage()); $errors[] = 'บันทึกหลักฐานไม่สำเร็จ กรุณาเลือกไฟล์และลองใหม่'; }
                $request = request_for_user($requestId, $user);
            }
        }
    }
}
if (empty($_SESSION['balance_keys'][$requestId])) { $_SESSION['balance_keys'][$requestId] = bin2hex(random_bytes(32)); }
$stmt=db()->prepare("SELECT COUNT(*) FROM balance_payments WHERE request_id=? AND status IN ('pending','approved')");$stmt->execute([$requestId]);$canSubmit=$request['status']==='completed' && !$stmt->fetchColumn() && (money_cents($request['deposit_amount']??'0')??0)>0;
$title = 'แจ้งชำระยอดคงเหลือ'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="request.php?id=<?= $requestId ?>">← กลับคำขอ <?= request_number($requestId) ?></a><div class="workspace-heading"><div><p class="eyebrow">BALANCE EVIDENCE</p><h1>แจ้งชำระยอดคงเหลือ</h1><p class="subtle"><?= e($request['title']) ?></p></div><span class="status-badge status-<?= e($request['status']) ?>"><?= e(status_label($request['status'])) ?></span></div>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach (array_unique($errors) as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul><p>กรุณาเลือกไฟล์สลิปอีกครั้งก่อนส่ง</p></div><?php endif; ?>
<?php if ($canSubmit): ?><div class="request-layout"><section class="form-card"><h2>แนบหลักฐานการโอน</h2><p class="subtle">โอนตามข้อมูลบัญชีที่ทีมงานแจ้ง แล้วส่งหลักฐานให้ตรวจสอบ</p><form method="post" enctype="multipart/form-data" class="stack-form"><?= csrf() ?><input type="hidden" name="submission_key" value="<?= e($_SESSION['balance_keys'][$requestId]) ?>">
<label class="upload-field">ภาพสลิปโอนเงิน<input type="file" name="slip[]" accept="image/jpeg,image/png,image/webp" required data-image-input data-max-files="1" aria-describedby="slip-help"><small id="slip-help">JPG, PNG หรือ WebP จำนวน 1 รูป ขนาดไม่เกิน 2 MB</small></label><p class="file-feedback subtle" data-file-feedback role="status"></p>
<label>หมายเหตุ (ไม่บังคับ)<textarea name="customer_note" rows="3" maxlength="1000" placeholder="ข้อมูลเพิ่มเติมสำหรับทีมงาน"><?= e($data['customer_note']) ?></textarea></label>
<button class="button full-width" type="submit">ส่งสลิปให้ทีมงานตรวจสอบ ↗</button></form></section><aside class="request-aside"><section class="panel accent-panel"><p class="eyebrow">BALANCE AMOUNT</p><h2><?= money($request['deposit_amount']) ?></h2><p>ยอดคงเหลือสำหรับ <?= request_number($requestId) ?></p><ol class="steps-list"><li><strong>แนบภาพสลิปที่อ่านชัด</strong><span>ให้เห็นยอด วันเวลา และข้อมูลผู้รับเงิน</span></li><li><strong>รอทีมงานตรวจสอบ</strong><span>การส่งสลิปยังไม่ใช่การยืนยันว่าได้รับชำระแล้ว</span></li><li><strong>ดูผลในคำขอของคุณ</strong><span>หากหลักฐานไม่ผ่าน จะมีเหตุผลให้แก้ไขและส่งใหม่</span></li></ol></section></aside></div>
<?php else: ?><section class="panel"><h2>ยังไม่สามารถส่งหลักฐานเพิ่มได้</h2><p>เปิดหน้าคำขอเพื่อตรวจสถานะและผลการตรวจหลักฐานล่าสุด</p><a class="button" href="request.php?id=<?= $requestId ?>">ดูคำขอ ↗</a></section><?php endif; ?></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
