<?php
require __DIR__ . '/includes/requests.php'; $user = require_user();
if (!is_reviewer($user)) { http_response_code(403); exit('เฉพาะพนักงานและผู้ดูแลระบบที่อัปเดตงานได้'); }
$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT) ?: 0;
$request = request_for_user($id, $user);
$stmt = db()->prepare('SELECT * FROM job_progress WHERE request_id = ?'); $stmt->execute([$id]); $progress = $stmt->fetch() ?: [];
$next = ['ready' => 'scheduled', 'scheduled' => 'traveling', 'traveling' => 'in_progress', 'in_progress' => 'completed'];
$options = isset($next[$request['status']]) ? [$next[$request['status']]] : [];
if (in_array($request['status'], ['scheduled','traveling','in_progress'], true)) { array_unshift($options, $request['status']); }
$data = ['status' => $next[$request['status']] ?? '', 'appointment_at' => isset($progress['appointment_at']) ? date('Y-m-d\TH:i', strtotime($progress['appointment_at'])) : '', 'arrival_at' => isset($progress['arrival_at']) ? date('Y-m-d\TH:i', strtotime($progress['arrival_at'])) : '', 'note' => ''];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); foreach ($data as $key => $_) { $data[$key] = post_string($key); }
    if (!in_array($data['status'], $options, true)) { $errors[] = 'สถานะไม่ถูกต้อง ไม่สามารถข้ามขั้นตอนหรือย้อนงานที่เสร็จแล้ว'; }
    if (mb_strlen($data['note']) < 3 || mb_strlen($data['note']) > 2000) { $errors[] = 'กรุณาระบุรายละเอียดความคืบหน้า 3–2,000 ตัวอักษร'; }
    $dates = [];
    foreach (['appointment_at','arrival_at'] as $field) {
        $value = $data[$field]; $date = $value !== '' ? DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value) : null;
        $dates[$field] = $date ? $date->format('Y-m-d H:i:s') : null;
        if ($value !== '' && (!$date || $date->format('Y-m-d\TH:i') !== $value)) { $errors[] = 'วันเวลานัดหมายหรือเวลาคาดว่าจะถึงไม่ถูกต้อง'; }
        elseif ($date && $dates[$field] !== ($progress[$field] ?? null) && ($date < new DateTimeImmutable() || $date > new DateTimeImmutable('+5 years'))) { $errors[] = 'วันเวลาที่เปลี่ยนใหม่ต้องไม่อยู่ในอดีต และไม่เกิน 5 ปีข้างหน้า'; }
    }
    if (!$dates['appointment_at']) { $errors[] = 'กรุณาระบุวันและเวลานัดหมาย'; }
    if (!$errors) {
        try {
            db()->beginTransaction();
            $stmt = db()->prepare('SELECT status FROM service_requests WHERE id = ? FOR UPDATE'); $stmt->execute([$id]); $lockedStatus = $stmt->fetchColumn();
            $stmt = db()->prepare('SELECT revision FROM job_progress WHERE request_id = ? FOR UPDATE'); $stmt->execute([$id]); $revision = (int) ($stmt->fetchColumn() ?: 0);
            if ($lockedStatus !== $request['status'] || $lockedStatus !== post_string('expected_status') || (string) $revision !== post_string('revision')) { throw new DomainException('มีการอัปเดตงานแล้ว กรุณาเปิดหน้านี้ใหม่ก่อนบันทึก'); }
            $stmt = db()->prepare('INSERT INTO job_progress (request_id, appointment_at, arrival_at, completed_at, revision) VALUES (?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE appointment_at=VALUES(appointment_at), arrival_at=VALUES(arrival_at), completed_at=VALUES(completed_at), revision=revision+1');
            $stmt->execute([$id, $dates['appointment_at'], $dates['arrival_at'], $data['status'] === 'completed' ? date('Y-m-d H:i:s') : null]);
            $stmt = db()->prepare('UPDATE service_requests SET status = ? WHERE id = ?'); $stmt->execute([$data['status'], $id]);
            $note = $data['note'] . '\nนัดหมาย: ' . short_date($dates['appointment_at']);
            if ($dates['arrival_at']) { $note .= '\nคาดว่าจะถึง: ' . short_date($dates['arrival_at']); }
            $stmt = db()->prepare('INSERT INTO request_status_history (request_id, actor_id, status, note) VALUES (?, ?, ?, ?)'); $stmt->execute([$id, $user['id'], $data['status'], str_replace('\\n', "\n", $note)]);
            db()->commit(); flash('อัปเดตสถานะงานแล้ว ลูกค้าดูความคืบหน้าได้ในคำขอ'); redirect('request.php?id=' . $id);
        } catch (Throwable $exception) {
            if (db()->inTransaction()) { db()->rollBack(); }
            if ($exception instanceof DomainException) { $errors[] = $exception->getMessage(); }
            else { error_log($exception->getMessage()); $errors[] = 'บันทึกไม่สำเร็จ กรุณาลองใหม่'; }
        }
    }
}
$title='อัปเดตความคืบหน้า'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace narrow"><a class="text-link" href="request.php?id=<?= $id ?>">← กลับคำขอ <?= request_number($id) ?></a><div class="workspace-heading"><div><p class="eyebrow">WORK PROGRESS</p><h1>อัปเดตความคืบหน้า</h1><p class="subtle"><?= e($request['title']) ?></p></div></div>
<?php if ($errors): ?><div class="alert error" role="alert"><?php foreach ($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?>
<section class="form-card"><?php if ($options): ?><p>สถานะปัจจุบัน: <strong><?= e(status_label($request['status'])) ?></strong></p><form method="post" class="stack-form"><?= csrf() ?><input type="hidden" name="expected_status" value="<?= e($request['status']) ?>"><input type="hidden" name="revision" value="<?= (int) ($progress['revision'] ?? 0) ?>">
<label>สถานะงาน<select name="status" required><?php foreach ($options as $status): ?><option value="<?= $status ?>" <?= $data['status'] === $status ? 'selected' : '' ?>><?= e(status_label($status)) ?><?= $status === $request['status'] ? ' (อัปเดตรายละเอียด)' : '' ?></option><?php endforeach; ?></select></label>
<label>วันและเวลานัดหมาย (เวลาไทย)<input type="datetime-local" name="appointment_at" required value="<?= e($data['appointment_at']) ?>"></label>
<label>คาดว่าจะถึงสถานที่ (ไม่บังคับ)<input type="datetime-local" name="arrival_at" value="<?= e($data['arrival_at']) ?>"></label>
<label>รายละเอียดความคืบหน้า<textarea name="note" required minlength="3" maxlength="2000" rows="4" placeholder="เช่น ทีมงานกำลังเดินทาง คาดว่าจะถึงตามเวลาที่แจ้ง"><?= e($data['note']) ?></textarea></label><button class="button" type="submit">บันทึกความคืบหน้า ↗</button></form><?php else: ?><p>สถานะนี้ยังอัปเดตความคืบหน้าไม่ได้ หรืองานเสร็จสิ้นแล้ว</p><?php endif; ?></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
