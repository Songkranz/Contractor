<?php
require __DIR__ . '/includes/requests.php'; $user=require_user();
if (!is_reviewer($user)) { http_response_code(403); exit('เฉพาะทีมงาน'); }
$id=filter_var($_GET['id']??'',FILTER_VALIDATE_INT)?:0; $request=request_for_user($id,$user); $errors=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
 verify_csrf(); $images=validate_request_images($errors); if (!$images) { $errors[]='กรุณาแนบภาพผลงาน'; }
 if ($request['status']!=='completed') { $errors[]='แนบภาพได้เมื่องานเสร็จสิ้นแล้ว'; }
 $saved=[];
 if (!$errors) { try {
  db()->beginTransaction(); $stmt=db()->prepare('SELECT status FROM service_requests WHERE id=? FOR UPDATE');$stmt->execute([$id]);
  if ($stmt->fetchColumn()!=='completed') { throw new DomainException('งานยังไม่เสร็จสิ้น'); }
  $stmt=db()->prepare('SELECT COUNT(*) FROM completion_images WHERE request_id=?');$stmt->execute([$id]);
  if ((int)$stmt->fetchColumn()+count($images)>3) { throw new DomainException('แนบภาพผลงานรวมได้ไม่เกิน 3 รูป'); }
  if (!is_dir(upload_directory()) && !mkdir(upload_directory(),0750,true) && !is_dir(upload_directory())) { throw new RuntimeException('Storage unavailable'); }
  foreach ($images as $image) {
   $path=upload_directory().'/'.$image['name']; if (!move_uploaded_file($image['tmp'],$path)) { throw new RuntimeException('Upload failed'); } $saved[]=$path;
   $stmt=db()->prepare('INSERT INTO completion_images (request_id,storage_name,mime_type,byte_size) VALUES (?,?,?,?)');$stmt->execute([$id,$image['name'],$image['mime'],$image['size']]);
  }
  $stmt=db()->prepare("INSERT INTO request_status_history (request_id,actor_id,status,note) VALUES (?,?,'completed',?)");$stmt->execute([$id,$user['id'],'ทีมงานแนบภาพผลงานเมื่อปิดงาน']);
  db()->commit();flash('แนบภาพผลงานแล้ว');redirect('request.php?id='.$id);
 } catch (Throwable $ex) { if(db()->inTransaction())db()->rollBack();foreach($saved as $path){if(is_file($path))unlink($path);} $errors[]=$ex instanceof DomainException?$ex->getMessage():'บันทึกไม่สำเร็จ กรุณาลองใหม่'; } }
}
$title='แนบภาพผลงาน';require __DIR__.'/includes/header.php';
?>
<main class="container workspace narrow"><a href="request.php?id=<?= $id ?>">← กลับคำขอ</a><h1>แนบภาพผลงานเมื่อปิดงาน</h1><?php foreach($errors as $error): ?><p class="alert error"><?= e($error) ?></p><?php endforeach; ?><?php if($request['status']==='completed'): ?><section class="form-card"><form method="post" enctype="multipart/form-data" class="stack-form"><?= csrf() ?><label>ภาพผลงาน (รวมสูงสุด 3 รูป รูปละไม่เกิน 2 MB)<input type="file" name="images[]" accept="image/jpeg,image/png,image/webp" multiple required></label><button class="button">บันทึกภาพผลงาน</button></form></section><?php else: ?><p>แนบภาพได้เมื่องานเสร็จสิ้นแล้ว</p><?php endif; ?></main>
<?php require __DIR__.'/includes/footer.php'; ?>
