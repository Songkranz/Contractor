<?php
require __DIR__ . '/includes/requests.php'; $user = require_admin(); $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $name = post_string('name'); $id = filter_var($_POST['id'] ?? '0', FILTER_VALIDATE_INT);
    $active = post_string('is_active');
    if ($id === false || $id < 0 || mb_strlen($name) < 1 || mb_strlen($name) > 100 || !in_array($active, ['0','1'], true)) { $error = 'กรุณาระบุชื่อประเภทงาน 1–100 ตัวอักษร และสถานะให้ถูกต้อง'; }
    else {
        try {
            if ($id) {
                $stmt = db()->prepare('SELECT id FROM job_types WHERE id = ?'); $stmt->execute([$id]);
                if (!$stmt->fetchColumn()) { throw new DomainException('ไม่พบประเภทงาน'); }
                $stmt = db()->prepare('UPDATE job_types SET name = ?, is_active = ? WHERE id = ?'); $stmt->execute([$name, $active, $id]);
            } else { $stmt = db()->prepare('INSERT INTO job_types (name, is_active) VALUES (?, ?)'); $stmt->execute([$name, $active]); }
            flash('บันทึกประเภทงานเรียบร้อยแล้ว'); redirect('job-types.php');
        } catch (Throwable $ex) {
            if ($ex instanceof DomainException) { $error = $ex->getMessage(); }
            elseif ($ex instanceof PDOException && ($ex->errorInfo[1] ?? 0) === 1062) { $error = 'ชื่อประเภทงานนี้มีอยู่แล้ว'; }
            else { error_log($ex->getMessage()); $error = 'บันทึกไม่สำเร็จ กรุณาลองใหม่'; }
        }
    }
}
$search=is_string($_GET['q']??null)?mb_substr(trim($_GET['q']),0,100):'';
$stmt=db()->prepare('SELECT t.*, (SELECT COUNT(*) FROM service_requests r WHERE r.job_type_id=t.id) AS usage_count FROM job_types t WHERE LOCATE(?,t.name)>0 ORDER BY t.id');$stmt->execute([$search]);$types=$stmt->fetchAll();
$title = 'จัดการประเภทงาน'; require __DIR__ . '/includes/header.php';
?>
<main class="container workspace"><a class="text-link" href="dashboard.php">← กลับแดชบอร์ด</a><div class="workspace-heading"><div><p class="eyebrow">JOB TYPES</p><h1>จัดการประเภทงาน</h1><p class="subtle">ประเภทที่ปิดใช้งานจะไม่แสดงในคำขอใหม่ คำขอเดิมยังดูได้ตามปกติ การเปลี่ยนชื่อจะปรับชื่อที่แสดงในคำขอเดิมด้วย</p></div></div>
<?php if ($error): ?><div class="alert error" role="alert"><?= e($error) ?></div><?php endif; ?>
<section class="panel"><h2>เพิ่มประเภทงาน</h2><form method="post" class="stack-form"><?= csrf() ?><input type="hidden" name="id" value="0"><input type="hidden" name="is_active" value="1"><label>ชื่อประเภทงาน<input name="name" maxlength="100" required value="<?= $error && !$id ? e($name) : '' ?>"></label><button class="button" type="submit">เพิ่มประเภทงาน</button></form></section>
<section class="panel"><h2>ประเภทงานทั้งหมด</h2><form method="get" class="search-form"><label class="sr-only" for="type-search">ค้นหาชื่อประเภทงาน</label><input id="type-search" name="q" maxlength="100" value="<?= e($search) ?>" placeholder="ค้นหาชื่อประเภทงาน"><button class="button">ค้นหา</button><a class="button button-outline" href="job-types.php">ล้าง</a></form><p class="subtle">พบ <?= count($types) ?> ประเภท</p><div class="table-scroll"><table><thead><tr><th>รหัส / จำนวนคำขอ</th><th>ชื่อและสถานะ</th></tr></thead><tbody>
<?php foreach ($types as $type): ?><tr><td>#<?= (int)$type['id'] ?><small><?= (int)$type['usage_count'] ?> คำขอ</small></td><td><form method="post" class="role-form"><?= csrf() ?><input type="hidden" name="id" value="<?= (int)$type['id'] ?>"><input name="name" aria-label="ชื่อประเภทงานรหัส <?= (int)$type['id'] ?>" maxlength="100" required value="<?= e($type['name']) ?>"><select name="is_active" aria-label="สถานะประเภทงานรหัส <?= (int)$type['id'] ?>"><option value="1" <?= $type['is_active'] ? 'selected' : '' ?>>เปิดใช้งาน</option><option value="0" <?= !$type['is_active'] ? 'selected' : '' ?>>ปิดใช้งาน</option></select><button class="button button-small" type="submit">บันทึก</button></form></td></tr><?php endforeach; ?>
<?php if(!$types): ?><tr><td colspan="2">ไม่พบประเภทงานที่ตรงกับคำค้นหา</td></tr><?php endif; ?></tbody></table></div></section></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
